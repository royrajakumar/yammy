// Firebase utility functions for the React app
// This file provides easy access to Firebase services

export const getFirebaseApp = () => {
  return window.firebaseApp;
};

export const getFirebaseAnalytics = () => {
  return window.firebaseAnalytics;
};

// Analytics helper functions
export const logEvent = (eventName, parameters = {}) => {
  if (window.firebaseAnalytics) {
    // You can import logEvent from firebase/analytics when needed
    console.log('Analytics event:', eventName, parameters);
  }
};

// Example usage functions for common e-commerce events
export const trackPurchase = (transactionId, value, currency = 'INR', items = []) => {
  logEvent('purchase', {
    transaction_id: transactionId,
    value: value,
    currency: currency,
    items: items
  });
};

export const trackAddToCart = (currency = 'INR', value, items = []) => {
  logEvent('add_to_cart', {
    currency: currency,
    value: value,
    items: items
  });
};

export const trackViewItem = (currency = 'INR', value, items = []) => {
  logEvent('view_item', {
    currency: currency,
    value: value,
    items: items
  });
};

export const trackBeginCheckout = (currency = 'INR', value, items = []) => {
  logEvent('begin_checkout', {
    currency: currency,
    value: value,
    items: items
  });
};