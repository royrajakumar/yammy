import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import WatchGrid from './components/WatchGrid';
import WatchCatalog from './components/WatchCatalog';
import Footer from './components/Footer';

// Import all pages
import AboutUs from './pages/AboutUs';
import OurCollection from './pages/OurCollection';
import BrandPartners from './pages/BrandPartners';
import StoreLocator from './pages/StoreLocator';
import WatchServices from './pages/WatchServices';
import WarrantyInfo from './pages/WarrantyInfo';
import SizeGuide from './pages/SizeGuide';
import CareInstructions from './pages/CareInstructions';
import ContactSupport from './pages/ContactSupport';
import FAQ from './pages/FAQ';
import BookAppointment from './pages/BookAppointment';
import TrackOrder from './pages/TrackOrder';
import ReturnsExchange from './pages/ReturnsExchange';
import ShippingInfo from './pages/ShippingInfo';
import PaymentOptions from './pages/PaymentOptions';
import LiveChat from './pages/LiveChat';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [cartItems, setCartItems] = useState([]);
  const [wishlistItems, setWishlistItems] = useState([]);
  const [showCatalog, setShowCatalog] = useState(false);
  const [returnToFooter, setReturnToFooter] = useState(false);

  const handleNavigate = (page, fromFooter = false) => {
    setCurrentPage(page);
    setReturnToFooter(fromFooter);
    
    if (page === 'home' && fromFooter) {
      // Delay scroll to footer to allow page to render
      setTimeout(() => {
        const footerElement = document.querySelector('footer');
        if (footerElement) {
          footerElement.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      // Smooth scroll to top for other pages
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleAddToCart = (watch) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === watch.id);
      if (existingItem) {
        return prevItems.map(item =>
          item.id === watch.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prevItems, { ...watch, quantity: 1 }];
      }
    });
  };

  const handleRemoveFromCart = (watchId) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== watchId));
  };

  const handleUpdateQuantity = (watchId, quantity) => {
    if (quantity <= 0) {
      handleRemoveFromCart(watchId);
      return;
    }
    
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === watchId
          ? { ...item, quantity }
          : item
      )
    );
  };

  const handleToggleWishlist = (watch) => {
    setWishlistItems(prevItems => {
      const isInWishlist = prevItems.some(item => item.id === watch.id);
      if (isInWishlist) {
        return prevItems.filter(item => item.id !== watch.id);
      } else {
        return [...prevItems, watch];
      }
    });
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleExploreCollection = () => {
    // Scroll to the watch grid section
    const watchGridElement = document.getElementById('watch-collection');
    if (watchGridElement) {
      watchGridElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleWatchCatalog = () => {
    setShowCatalog(true);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'about':
        return <AboutUs onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'collection':
        return <OurCollection onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'brands':
        return <BrandPartners onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'stores':
        return <StoreLocator onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'services':
        return <WatchServices onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'warranty':
        return <WarrantyInfo onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'size-guide':
        return <SizeGuide onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'care':
        return <CareInstructions onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'contact-support':
        return <ContactSupport onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'faq':
        return <FAQ onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'appointment':
        return <BookAppointment onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'track-order':
        return <TrackOrder onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'returns':
        return <ReturnsExchange onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'shipping':
        return <ShippingInfo onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'payment':
        return <PaymentOptions onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'chat':
        return <LiveChat onNavigate={(page) => handleNavigate(page, returnToFooter)} />;
      case 'home':
      default:
        return (
          <>
            <Header
              onNavigate={handleNavigate}
              cartItems={cartItems}
              wishlistItems={wishlistItems}
              onAddToCart={handleAddToCart}
              onRemoveFromCart={handleRemoveFromCart}
              onUpdateQuantity={handleUpdateQuantity}
              onToggleWishlist={handleToggleWishlist}
              onClearCart={handleClearCart}
              isTransparent={true}
            />
            <div className="min-h-screen">
              <Hero 
                onExploreCollection={handleExploreCollection}
                onWatchCatalog={handleWatchCatalog}
              />
              <div id="watch-collection">
                <WatchGrid
                  onAddToCart={handleAddToCart}
                  onToggleWishlist={handleToggleWishlist}
                  cartItems={cartItems}
                  wishlistItems={wishlistItems}
                />
              </div>
              <Footer onNavigate={(page) => handleNavigate(page, true)} />
            </div>
          </>
        );
    }
  };

  // Show header for all pages except home (home has its own transparent header)
  if (currentPage !== 'home') {
    return (
      <>
        <Header
          onNavigate={handleNavigate}
          cartItems={cartItems}
          wishlistItems={wishlistItems}
          onAddToCart={handleAddToCart}
          onRemoveFromCart={handleRemoveFromCart}
          onUpdateQuantity={handleUpdateQuantity}
          onToggleWishlist={handleToggleWishlist}
          onClearCart={handleClearCart}
          isTransparent={false}
        />
        <div className="pt-0">
          {renderPage()}
        </div>
      </>
    );
  }

  return (
    <>
      {renderPage()}
      {showCatalog && (
        <WatchCatalog onClose={() => setShowCatalog(false)} />
      )}
    </>
  );
}

export default App;