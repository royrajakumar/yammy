// Watch type definitions for JSDoc comments

/**
 * @typedef {Object} Watch
 * @property {string} id
 * @property {string} name
 * @property {string} brand
 * @property {number} price
 * @property {string} image
 * @property {string} description
 * @property {'luxury'|'sport'|'classic'|'smart'} category
 * @property {'men'|'women'|'unisex'} gender
 * @property {string} material
 * @property {string} movement
 * @property {string[]} features
 * @property {string} waterResistance
 * @property {string} warranty
 */

/**
 * @typedef {Object} Brand
 * @property {string} name
 * @property {string} logo
 * @property {string} description
 * @property {string} founded
 * @property {string} country
 */

/**
 * @typedef {Object} PageProps
 * @property {function(string): void} onNavigate
 */

export {};