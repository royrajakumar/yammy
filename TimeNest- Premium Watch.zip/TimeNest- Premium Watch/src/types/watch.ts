export interface Watch {
  id: string;
  name: string;
  brand: string;
  price: number;
  image: string;
  description: string;
  category: 'luxury' | 'sport' | 'classic' | 'smart';
  gender: 'men' | 'women' | 'unisex';
  material: string;
  movement: string;
  features: string[];
  waterResistance: string;
  warranty: string;
}

export interface Brand {
  name: string;
  logo: string;
  description: string;
  founded: string;
  country: string;
}

export interface PageProps {
  onNavigate: (page: string) => void;
}

export interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  emailVerified: boolean;
}