import React, { useState } from 'react';
import { ArrowLeft, Ruler, Hand, Info, CheckCircle } from 'lucide-react';
import { PageProps } from '../types/watch';

const SizeGuide: React.FC<PageProps> = ({ onNavigate }) => {
  const [selectedGender, setSelectedGender] = useState<'men' | 'women' | 'unisex'>('men');

  const sizeGuides = {
    men: {
      wrist: [
        { size: 'Small', range: '6.0" - 6.5"', mm: '152-165mm', caseSize: '38-40mm', recommendation: 'Classic dress watches' },
        { size: 'Medium', range: '6.5" - 7.0"', mm: '165-178mm', caseSize: '40-42mm', recommendation: 'Most versatile size' },
        { size: 'Large', range: '7.0" - 7.5"', mm: '178-191mm', caseSize: '42-44mm', recommendation: 'Sport and luxury watches' },
        { size: 'Extra Large', range: '7.5" - 8.0"', mm: '191-203mm', caseSize: '44-46mm', recommendation: 'Bold statement pieces' }
      ]
    },
    women: {
      wrist: [
        { size: 'Petite', range: '5.5" - 6.0"', mm: '140-152mm', caseSize: '26-30mm', recommendation: 'Delicate jewelry watches' },
        { size: 'Small', range: '6.0" - 6.5"', mm: '152-165mm', caseSize: '30-34mm', recommendation: 'Classic feminine styles' },
        { size: 'Medium', range: '6.5" - 7.0"', mm: '165-178mm', caseSize: '34-38mm', recommendation: 'Modern versatile designs' },
        { size: 'Large', range: '7.0" - 7.5"', mm: '178-191mm', caseSize: '38-40mm', recommendation: 'Bold contemporary pieces' }
      ]
    },
    unisex: {
      wrist: [
        { size: 'Small', range: '6.0" - 6.5"', mm: '152-165mm', caseSize: '36-38mm', recommendation: 'Minimalist designs' },
        { size: 'Medium', range: '6.5" - 7.0"', mm: '165-178mm', caseSize: '38-40mm', recommendation: 'Universal appeal' },
        { size: 'Large', range: '7.0" - 7.5"', mm: '178-191mm', caseSize: '40-42mm', recommendation: 'Contemporary styles' }
      ]
    }
  };

  const measurementTips = [
    {
      step: 1,
      title: 'Use a Measuring Tape',
      description: 'Wrap a flexible measuring tape around your wrist just below the wrist bone',
      icon: Ruler
    },
    {
      step: 2,
      title: 'String Method',
      description: 'Use a string, then measure it against a ruler for accurate measurement',
      icon: Hand
    },
    {
      step: 3,
      title: 'Paper Strip',
      description: 'Cut a paper strip, wrap around wrist, mark overlap, then measure',
      icon: Info
    },
    {
      step: 4,
      title: 'Professional Fitting',
      description: 'Visit our store for professional sizing and personalized recommendations',
      icon: CheckCircle
    }
  ];

  const strapGuide = [
    {
      type: 'Leather Straps',
      sizes: ['18mm', '20mm', '22mm', '24mm'],
      description: 'Classic and elegant, perfect for dress watches',
      care: 'Avoid water exposure, condition regularly'
    },
    {
      type: 'Metal Bracelets',
      sizes: ['18mm', '20mm', '22mm', '24mm'],
      description: 'Durable and versatile for daily wear',
      care: 'Clean with soft brush and mild soap'
    },
    {
      type: 'Rubber Straps',
      sizes: ['20mm', '22mm', '24mm'],
      description: 'Perfect for sports and water activities',
      care: 'Rinse with fresh water after use'
    },
    {
      type: 'NATO Straps',
      sizes: ['18mm', '20mm', '22mm'],
      description: 'Casual and comfortable for everyday wear',
      care: 'Machine washable on gentle cycle'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <Ruler className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Watch Size Guide</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Find your perfect watch size for comfort and style
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* How to Measure */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">How to Measure Your Wrist</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {measurementTips.map((tip, index) => {
              const IconComponent = tip.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-blue-600" />
                  </div>
                  <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-sm font-bold">
                    {tip.step}
                  </div>
                  <h3 className="font-semibold text-gray-800 mb-2">{tip.title}</h3>
                  <p className="text-gray-600 text-sm">{tip.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Size Guide Selector */}
        <div className="mb-8">
          <div className="flex justify-center gap-4">
            {(['men', 'women', 'unisex'] as const).map((gender) => (
              <button
                key={gender}
                onClick={() => setSelectedGender(gender)}
                className={`px-6 py-3 rounded-full font-semibold transition-colors ${
                  selectedGender === gender
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                {gender.charAt(0).toUpperCase() + gender.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Size Chart */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-16">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
            <h2 className="text-2xl font-bold text-center">
              {selectedGender.charAt(0).toUpperCase() + selectedGender.slice(1)} Watch Size Chart
            </h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left font-semibold text-gray-800">Wrist Size</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-800">Inches</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-800">Millimeters</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-800">Recommended Case Size</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-800">Best For</th>
                </tr>
              </thead>
              <tbody>
                {sizeGuides[selectedGender].wrist.map((size, index) => (
                  <tr key={index} className="border-t hover:bg-gray-50">
                    <td className="px-6 py-4 font-semibold text-blue-600">{size.size}</td>
                    <td className="px-6 py-4">{size.range}</td>
                    <td className="px-6 py-4">{size.mm}</td>
                    <td className="px-6 py-4 font-semibold">{size.caseSize}</td>
                    <td className="px-6 py-4 text-gray-600">{size.recommendation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Strap Guide */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Strap & Bracelet Guide</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {strapGuide.map((strap, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                <h3 className="text-xl font-bold text-gray-800 mb-4">{strap.type}</h3>
                
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-700 mb-2">Available Sizes:</h4>
                  <div className="flex flex-wrap gap-2">
                    {strap.sizes.map((size, idx) => (
                      <span key={idx} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                        {size}
                      </span>
                    ))}
                  </div>
                </div>
                
                <p className="text-gray-600 text-sm mb-4">{strap.description}</p>
                
                <div className="border-t pt-4">
                  <h4 className="font-semibold text-gray-700 mb-1">Care Tips:</h4>
                  <p className="text-gray-600 text-xs">{strap.care}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Fit Tips */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <h2 className="text-3xl font-bold text-center mb-8">Perfect Fit Tips</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Comfort First</h4>
              <p className="text-sm text-blue-100">Your watch should feel comfortable throughout the day without being too tight or loose</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Hand className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Finger Test</h4>
              <p className="text-sm text-blue-100">You should be able to slide a finger under the strap comfortably</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Ruler className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Professional Sizing</h4>
              <p className="text-sm text-blue-100">Visit our stores for expert fitting and personalized recommendations</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SizeGuide;