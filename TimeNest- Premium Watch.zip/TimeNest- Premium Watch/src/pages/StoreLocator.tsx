import React, { useState } from 'react';
import { ArrowLeft, MapPin, Phone, Clock, Navigation, Car, Train, Plane } from 'lucide-react';
import { PageProps } from '../types/watch';

const StoreLocator: React.FC<PageProps> = ({ onNavigate }) => {
  const [selectedStore, setSelectedStore] = useState(0);

  const stores = [
    {
      id: 1,
      name: 'TimeNest Flagship - Connaught Place',
      address: '123 Luxury Plaza, Connaught Place, New Delhi 110001',
      phone: '+91 11 2345 6789',
      hours: 'Mon-Sat: 10:00 AM - 9:00 PM, Sun: 11:00 AM - 8:00 PM',
      features: ['Full Collection', 'Watch Servicing', 'VIP Lounge', 'Expert Consultation'],
      image: 'https://images.pexels.com/photos/1034063/pexels-photo-1034063.jpeg?auto=compress&cs=tinysrgb&w=600',
      transport: ['Metro: Rajiv Chowk', 'Bus: CP Central', 'Parking Available']
    },
    {
      id: 2,
      name: 'TimeNest Premium - Khan Market',
      address: '45 Khan Market, New Delhi 110003',
      phone: '+91 11 2345 6790',
      hours: 'Mon-Sat: 10:30 AM - 8:30 PM, Sun: 12:00 PM - 7:00 PM',
      features: ['Luxury Brands', 'Personal Shopping', 'Gift Wrapping', 'Home Delivery'],
      image: 'https://images.pexels.com/photos/277390/pexels-photo-277390.jpeg?auto=compress&cs=tinysrgb&w=600',
      transport: ['Metro: Khan Market', 'Bus: Khan Market', 'Valet Parking']
    },
    {
      id: 3,
      name: 'TimeNest Select - Gurgaon',
      address: '78 DLF Cyber City, Gurgaon 122002',
      phone: '+91 124 2345 6791',
      hours: 'Mon-Sun: 11:00 AM - 9:00 PM',
      features: ['Corporate Sales', 'Bulk Orders', 'Executive Lounge', 'Express Service'],
      image: 'https://images.pexels.com/photos/1697214/pexels-photo-1697214.jpeg?auto=compress&cs=tinysrgb&w=600',
      transport: ['Metro: Cyber City', 'Corporate Shuttle', 'Multi-level Parking']
    },
    {
      id: 4,
      name: 'TimeNest Boutique - Mumbai',
      address: '156 Linking Road, Bandra West, Mumbai 400050',
      phone: '+91 22 2345 6792',
      hours: 'Mon-Sat: 10:00 AM - 10:00 PM, Sun: 11:00 AM - 9:00 PM',
      features: ['Celebrity Collection', 'Custom Engraving', 'Watch Bar', 'Style Consultation'],
      image: 'https://images.pexels.com/photos/1697215/pexels-photo-1697215.jpeg?auto=compress&cs=tinysrgb&w=600',
      transport: ['Metro: Bandra', 'Local: Bandra Station', 'Street Parking']
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-5xl font-bold mb-4">Find Our Stores</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Visit our premium locations across India for the complete TimeNest experience
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Store Selection */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Store List */}
          <div className="lg:col-span-1">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Our Locations</h2>
            <div className="space-y-4">
              {stores.map((store, index) => (
                <div
                  key={store.id}
                  onClick={() => setSelectedStore(index)}
                  className={`p-4 rounded-xl cursor-pointer transition-all duration-200 ${
                    selectedStore === index
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'bg-white hover:bg-gray-50 shadow-md'
                  }`}
                >
                  <h3 className="font-semibold mb-2">{store.name}</h3>
                  <div className="flex items-start gap-2 text-sm opacity-90">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{store.address}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Store Details */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
              <img
                src={stores[selectedStore].image}
                alt={stores[selectedStore].name}
                className="w-full h-64 object-cover"
              />
              
              <div className="p-8">
                <h2 className="text-3xl font-bold text-gray-800 mb-4">
                  {stores[selectedStore].name}
                </h2>
                
                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-blue-600 mt-1" />
                      <div>
                        <h4 className="font-semibold text-gray-800">Address</h4>
                        <p className="text-gray-600">{stores[selectedStore].address}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <Phone className="w-5 h-5 text-green-600 mt-1" />
                      <div>
                        <h4 className="font-semibold text-gray-800">Phone</h4>
                        <p className="text-gray-600">{stores[selectedStore].phone}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <Clock className="w-5 h-5 text-purple-600 mt-1" />
                      <div>
                        <h4 className="font-semibold text-gray-800">Hours</h4>
                        <p className="text-gray-600">{stores[selectedStore].hours}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">Store Features</h4>
                    <div className="space-y-2">
                      {stores[selectedStore].features.map((feature, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                          <span className="text-gray-600">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Transportation */}
                <div className="border-t pt-6">
                  <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                    <Navigation className="w-5 h-5 text-blue-600" />
                    How to Reach
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {stores[selectedStore].transport.map((option, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                        {option.includes('Metro') && <Train className="w-4 h-4 text-blue-500" />}
                        {option.includes('Bus') && <Car className="w-4 h-4 text-green-500" />}
                        {option.includes('Parking') && <Car className="w-4 h-4 text-purple-500" />}
                        {option.includes('Shuttle') && <Plane className="w-4 h-4 text-orange-500" />}
                        <span>{option}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 mt-8">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full font-semibold transition-colors flex-1">
                    Get Directions
                  </button>
                  <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-6 py-3 rounded-full font-semibold transition-colors flex-1">
                    Call Store
                  </button>
                  <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full font-semibold transition-colors flex-1">
                    Book Appointment
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Store Network Stats */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <h2 className="text-3xl font-bold text-center mb-8">Our Growing Network</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">4</div>
              <div className="text-blue-100">Premium Stores</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">3</div>
              <div className="text-blue-100">Major Cities</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-blue-100">Expert Staff</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">24/7</div>
              <div className="text-blue-100">Customer Support</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoreLocator;