import React from 'react';
import { ArrowLeft, MapPin, Calendar, Award, ExternalLink } from 'lucide-react';
import { PageProps } from '../types/watch';
import { brands } from '../data/watches';

const BrandPartners: React.FC<PageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-5xl font-bold mb-4">Our Brand Partners</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            We're proud to be authorized dealers for 20 of the world's most prestigious watch brands
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Partnership Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">20</h3>
            <p className="text-gray-600">Authorized Brand Partners</p>
          </div>
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">14+</h3>
            <p className="text-gray-600">Years of Partnership</p>
          </div>
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MapPin className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">8</h3>
            <p className="text-gray-600">Countries Represented</p>
          </div>
        </div>

        {/* Brand Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {brands.map((brand, index) => (
            <div key={brand.name} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="p-8">
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-4xl">{brand.logo}</div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800">{brand.name}</h3>
                    <p className="text-gray-600">{brand.description}</p>
                  </div>
                </div>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>Founded: {brand.founded}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span>Origin: {brand.country}</span>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">
                      Partnership since 2010
                    </span>
                    <button className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm font-medium">
                      View Collection
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Partnership Benefits */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <h2 className="text-3xl font-bold text-center mb-8">Partnership Benefits</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Award className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Authentic Products</h4>
              <p className="text-sm text-blue-100">Direct from authorized distributors</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Calendar className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Latest Collections</h4>
              <p className="text-sm text-blue-100">First access to new releases</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <MapPin className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Global Warranty</h4>
              <p className="text-sm text-blue-100">International service coverage</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <ExternalLink className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Expert Support</h4>
              <p className="text-sm text-blue-100">Brand-certified technicians</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrandPartners;