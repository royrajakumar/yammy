import React from 'react';
import { ArrowLeft, Wrench, Shield, Clock, Sparkles, Award, RefreshCw } from 'lucide-react';
import { PageProps } from '../types/watch';

const WatchServices: React.FC<PageProps> = ({ onNavigate }) => {
  const services = [
    {
      icon: Wrench,
      title: 'Complete Servicing',
      description: 'Full mechanical and electronic servicing by certified technicians',
      features: ['Movement cleaning', 'Lubrication', 'Calibration', 'Water resistance testing'],
      price: 'From ₹2,500',
      duration: '7-14 days',
      color: 'blue'
    },
    {
      icon: Shield,
      title: 'Battery Replacement',
      description: 'Quick and professional battery replacement for quartz watches',
      features: ['Genuine batteries', 'Seal replacement', 'Water resistance check', 'Function testing'],
      price: 'From ₹500',
      duration: '30 minutes',
      color: 'green'
    },
    {
      icon: Sparkles,
      title: 'Watch Cleaning',
      description: 'Professional cleaning and polishing to restore your watch\'s shine',
      features: ['Ultrasonic cleaning', 'Case polishing', 'Bracelet cleaning', 'Crystal polishing'],
      price: 'From ₹1,200',
      duration: '2-3 days',
      color: 'purple'
    },
    {
      icon: RefreshCw,
      title: 'Strap Replacement',
      description: 'Wide selection of genuine and premium aftermarket straps',
      features: ['Leather straps', 'Metal bracelets', 'Rubber bands', 'NATO straps'],
      price: 'From ₹800',
      duration: '15 minutes',
      color: 'orange'
    },
    {
      icon: Award,
      title: 'Authenticity Check',
      description: 'Professional authentication service for pre-owned watches',
      features: ['Movement verification', 'Serial number check', 'Component analysis', 'Certificate'],
      price: 'From ₹1,500',
      duration: '1-2 days',
      color: 'red'
    },
    {
      icon: Clock,
      title: 'Regulation & Timing',
      description: 'Precision timing adjustment for optimal accuracy',
      features: ['Timing analysis', 'Regulation adjustment', 'Position testing', 'Accuracy report'],
      price: 'From ₹1,000',
      duration: '3-5 days',
      color: 'indigo'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-100 text-blue-600',
      green: 'bg-green-100 text-green-600',
      purple: 'bg-purple-100 text-purple-600',
      orange: 'bg-orange-100 text-orange-600',
      red: 'bg-red-100 text-red-600',
      indigo: 'bg-indigo-100 text-indigo-600'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-5xl font-bold mb-4">Watch Services</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Expert care for your timepieces by certified technicians using genuine parts
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Service Promise */}
        <div className="bg-white rounded-3xl shadow-xl p-8 mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">Our Service Promise</h2>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Certified Technicians</h3>
              <p className="text-sm text-gray-600">Factory-trained experts</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Genuine Parts</h3>
              <p className="text-sm text-gray-600">Only authentic components</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Quick Turnaround</h3>
              <p className="text-sm text-gray-600">Fast and reliable service</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <RefreshCw className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Service Warranty</h3>
              <p className="text-sm text-gray-600">6-month guarantee</p>
            </div>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden">
                <div className="p-6">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${getColorClasses(service.color)}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  
                  <div className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                        <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="border-t pt-4 flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-gray-800">{service.price}</div>
                      <div className="text-sm text-gray-500">{service.duration}</div>
                    </div>
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full text-sm font-medium transition-colors">
                      Book Service
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Service Process */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <h2 className="text-3xl font-bold text-center mb-8">Our Service Process</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">1</span>
              </div>
              <h4 className="font-semibold mb-2">Drop Off</h4>
              <p className="text-sm text-blue-100">Bring your watch to any of our stores</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">2</span>
              </div>
              <h4 className="font-semibold mb-2">Diagnosis</h4>
              <p className="text-sm text-blue-100">Free evaluation and quote</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">3</span>
              </div>
              <h4 className="font-semibold mb-2">Service</h4>
              <p className="text-sm text-blue-100">Expert repair and maintenance</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">4</span>
              </div>
              <h4 className="font-semibold mb-2">Pickup</h4>
              <p className="text-sm text-blue-100">Collect your restored timepiece</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WatchServices;