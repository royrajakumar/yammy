import React, { useState } from 'react';
import { ArrowLeft, RotateCcw, Package, CheckCircle, Clock, AlertCircle, FileText, Camera, Truck, CreditCard } from 'lucide-react';
import { PageProps } from '../types/watch';

const ReturnsExchange: React.FC<PageProps> = ({ onNavigate }) => {
  const [selectedTab, setSelectedTab] = useState<'policy' | 'initiate' | 'status'>('policy');
  const [returnType, setReturnType] = useState<'return' | 'exchange'>('return');
  const [returnReason, setReturnReason] = useState('');
  const [orderNumber, setOrderNumber] = useState('');

  const returnReasons = [
    { id: 'defective', label: 'Defective/Damaged Product', description: 'Product arrived damaged or has manufacturing defects' },
    { id: 'wrong-item', label: 'Wrong Item Received', description: 'Received different product than ordered' },
    { id: 'size-issue', label: 'Size/Fit Issue', description: 'Watch doesn\'t fit properly' },
    { id: 'not-as-described', label: 'Not as Described', description: 'Product doesn\'t match description or images' },
    { id: 'change-mind', label: 'Changed Mind', description: 'No longer want the product' },
    { id: 'better-price', label: 'Found Better Price', description: 'Found the same product at a lower price' },
    { id: 'gift-return', label: 'Gift Return', description: 'Returning a gift' },
    { id: 'other', label: 'Other', description: 'Other reason not listed above' }
  ];

  const policyHighlights = [
    {
      icon: Clock,
      title: '30-Day Return Window',
      description: 'Return unworn watches within 30 days of delivery',
      color: 'blue'
    },
    {
      icon: Package,
      title: 'Original Packaging Required',
      description: 'All original packaging, tags, and accessories must be included',
      color: 'green'
    },
    {
      icon: CheckCircle,
      title: 'Free Returns for Defects',
      description: 'No charges for returning defective or damaged items',
      color: 'purple'
    },
    {
      icon: CreditCard,
      title: 'Quick Refunds',
      description: 'Refunds processed within 5-7 business days',
      color: 'orange'
    }
  ];

  const returnProcess = [
    {
      step: 1,
      title: 'Initiate Return',
      description: 'Fill out the return form with order details and reason',
      icon: FileText
    },
    {
      step: 2,
      title: 'Get Return Label',
      description: 'Receive prepaid return shipping label via email',
      icon: Package
    },
    {
      step: 3,
      title: 'Pack & Ship',
      description: 'Pack the item securely and attach the return label',
      icon: Truck
    },
    {
      step: 4,
      title: 'Refund Processing',
      description: 'Receive refund once we inspect the returned item',
      icon: CreditCard
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-100 text-blue-600',
      green: 'bg-green-100 text-green-600',
      purple: 'bg-purple-100 text-purple-600',
      orange: 'bg-orange-100 text-orange-600'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const handleSubmitReturn = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Return request submitted successfully! You will receive a confirmation email shortly.');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <RotateCcw className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Returns & Exchanges</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Easy returns and exchanges with our hassle-free process
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Tab Navigation */}
        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-full p-1 shadow-lg">
            <button
              onClick={() => setSelectedTab('policy')}
              className={`px-6 py-3 rounded-full font-semibold transition-colors ${
                selectedTab === 'policy' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Return Policy
            </button>
            <button
              onClick={() => setSelectedTab('initiate')}
              className={`px-6 py-3 rounded-full font-semibold transition-colors ${
                selectedTab === 'initiate' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Start Return
            </button>
            <button
              onClick={() => setSelectedTab('status')}
              className={`px-6 py-3 rounded-full font-semibold transition-colors ${
                selectedTab === 'status' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Check Status
            </button>
          </div>
        </div>

        {/* Policy Tab */}
        {selectedTab === 'policy' && (
          <div className="space-y-12">
            {/* Policy Highlights */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {policyHighlights.map((highlight, index) => {
                const IconComponent = highlight.icon;
                return (
                  <div key={index} className="bg-white rounded-2xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${getColorClasses(highlight.color)}`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">{highlight.title}</h3>
                    <p className="text-gray-600 text-sm">{highlight.description}</p>
                  </div>
                );
              })}
            </div>

            {/* Detailed Policy */}
            <div className="grid lg:grid-cols-2 gap-8">
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex items-center gap-3 mb-6">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  <h2 className="text-2xl font-bold text-gray-800">What Can Be Returned</h2>
                </div>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                    <span>Unworn watches in original condition</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                    <span>Items with all original packaging and accessories</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                    <span>Products with original warranty cards and documentation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                    <span>Items returned within 30 days of delivery</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                    <span>Defective or damaged products (any time within warranty)</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex items-center gap-3 mb-6">
                  <AlertCircle className="w-6 h-6 text-red-600" />
                  <h2 className="text-2xl font-bold text-gray-800">What Cannot Be Returned</h2>
                </div>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-600 rounded-full mt-2"></div>
                    <span>Worn or used watches showing signs of wear</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-600 rounded-full mt-2"></div>
                    <span>Items without original packaging or accessories</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-600 rounded-full mt-2"></div>
                    <span>Customized or engraved watches</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-600 rounded-full mt-2"></div>
                    <span>Items returned after 30-day window (unless defective)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-600 rounded-full mt-2"></div>
                    <span>Damage caused by misuse or accidents</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Return Process */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-8 text-center">Return Process</h2>
              <div className="grid md:grid-cols-4 gap-8">
                {returnProcess.map((process, index) => {
                  const IconComponent = process.icon;
                  return (
                    <div key={index} className="text-center">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <IconComponent className="w-8 h-8 text-blue-600" />
                      </div>
                      <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-sm font-bold">
                        {process.step}
                      </div>
                      <h3 className="font-semibold text-gray-800 mb-2">{process.title}</h3>
                      <p className="text-gray-600 text-sm">{process.description}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Initiate Return Tab */}
        {selectedTab === 'initiate' && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Start Your Return or Exchange</h2>
              
              {/* Return Type Selection */}
              <div className="mb-8">
                <h3 className="font-semibold text-gray-800 mb-4">What would you like to do?</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <label className="block">
                    <input
                      type="radio"
                      name="returnType"
                      value="return"
                      checked={returnType === 'return'}
                      onChange={(e) => setReturnType(e.target.value as 'return' | 'exchange')}
                      className="sr-only"
                    />
                    <div className={`p-6 border-2 rounded-xl cursor-pointer transition-colors ${
                      returnType === 'return' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <div className="flex items-center gap-3 mb-2">
                        <RotateCcw className="w-6 h-6 text-blue-600" />
                        <h4 className="font-semibold text-gray-800">Return for Refund</h4>
                      </div>
                      <p className="text-gray-600 text-sm">Get your money back for the returned item</p>
                    </div>
                  </label>
                  
                  <label className="block">
                    <input
                      type="radio"
                      name="returnType"
                      value="exchange"
                      checked={returnType === 'exchange'}
                      onChange={(e) => setReturnType(e.target.value as 'return' | 'exchange')}
                      className="sr-only"
                    />
                    <div className={`p-6 border-2 rounded-xl cursor-pointer transition-colors ${
                      returnType === 'exchange' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <div className="flex items-center gap-3 mb-2">
                        <Package className="w-6 h-6 text-green-600" />
                        <h4 className="font-semibold text-gray-800">Exchange Item</h4>
                      </div>
                      <p className="text-gray-600 text-sm">Replace with a different size, color, or model</p>
                    </div>
                  </label>
                </div>
              </div>

              <form onSubmit={handleSubmitReturn} className="space-y-6">
                {/* Order Information */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Order Number *</label>
                    <input
                      type="text"
                      required
                      value={orderNumber}
                      onChange={(e) => setOrderNumber(e.target.value)}
                      placeholder="TN-2024-XXXXXX"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="your.email@example.com"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Return Reason */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-4">Reason for {returnType} *</label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {returnReasons.map((reason) => (
                      <label key={reason.id} className="block">
                        <input
                          type="radio"
                          name="returnReason"
                          value={reason.id}
                          checked={returnReason === reason.id}
                          onChange={(e) => setReturnReason(e.target.value)}
                          className="sr-only"
                        />
                        <div className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                          returnReason === reason.id ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                        }`}>
                          <h4 className="font-medium text-gray-800 mb-1">{reason.label}</h4>
                          <p className="text-gray-600 text-xs">{reason.description}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Additional Details */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Additional Details</label>
                  <textarea
                    rows={4}
                    placeholder="Please provide any additional information about your return..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  ></textarea>
                </div>

                {/* Photo Upload */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Upload Photos (Optional)
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                    <Camera className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600 mb-2">Upload photos of the item or issue</p>
                    <button type="button" className="bg-gray-100 text-gray-600 px-4 py-2 rounded-lg text-sm hover:bg-gray-200 transition-colors">
                      Choose Files
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                >
                  Submit {returnType === 'return' ? 'Return' : 'Exchange'} Request
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Status Tab */}
        {selectedTab === 'status' && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Check Return Status</h2>
              
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Return Request Number</label>
                  <input
                    type="text"
                    placeholder="RET-2024-XXXXXX"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input
                    type="email"
                    placeholder="your.email@example.com"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                >
                  Check Status
                </button>
              </form>

              <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold text-blue-800 mb-2">Don't have your return number?</h3>
                <p className="text-blue-700 text-sm mb-3">
                  You can find it in the confirmation email we sent when you submitted your return request.
                </p>
                <button 
                  onClick={() => onNavigate('contact-support')}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors"
                >
                  Contact Support
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReturnsExchange;