import React, { useState } from 'react';
import { ArrowLeft, Phone, Mail, MessageCircle, Clock, MapPin, Send, User, HelpCircle } from 'lucide-react';
import { PageProps } from '../types/watch';

const ContactSupport: React.FC<PageProps> = ({ onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState('general');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    category: 'general',
    subject: '',
    message: '',
    orderNumber: ''
  });

  const supportCategories = [
    { id: 'general', name: 'General Inquiry', icon: HelpCircle },
    { id: 'order', name: 'Order Support', icon: Phone },
    { id: 'technical', name: 'Technical Issue', icon: MessageCircle },
    { id: 'warranty', name: 'Warranty Claim', icon: Clock },
    { id: 'service', name: 'Service Request', icon: MapPin }
  ];

  const contactMethods = [
    {
      method: 'Phone Support',
      icon: Phone,
      details: '+91 11 2345 6789',
      availability: '24/7 Customer Support',
      description: 'Speak directly with our support team',
      color: 'blue'
    },
    {
      method: 'Email Support',
      icon: Mail,
      details: 'support@timenest.com',
      availability: 'Response within 2 hours',
      description: 'Send us detailed queries via email',
      color: 'green'
    },
    {
      method: 'Live Chat',
      icon: MessageCircle,
      details: 'Available on website',
      availability: 'Mon-Sat: 9 AM - 9 PM',
      description: 'Instant chat with support agents',
      color: 'purple'
    },
    {
      method: 'WhatsApp',
      icon: MessageCircle,
      details: '+91 98765 43210',
      availability: '24/7 Automated + Live Support',
      description: 'Quick support via WhatsApp',
      color: 'green'
    }
  ];

  const faqCategories = [
    {
      category: 'Orders & Shipping',
      questions: [
        { q: 'How long does shipping take?', a: 'Standard shipping takes 3-5 business days, express shipping 1-2 days.' },
        { q: 'Can I track my order?', a: 'Yes, you\'ll receive a tracking number via email once your order ships.' },
        { q: 'Do you ship internationally?', a: 'Currently we ship within India only, international shipping coming soon.' }
      ]
    },
    {
      category: 'Returns & Exchanges',
      questions: [
        { q: 'What is your return policy?', a: '30-day return policy for unworn watches in original packaging.' },
        { q: 'How do I initiate a return?', a: 'Contact our support team or visit any TimeNest store with your order details.' },
        { q: 'Are there any return fees?', a: 'Returns are free for defective items, ₹200 fee for change of mind returns.' }
      ]
    },
    {
      category: 'Warranty & Service',
      questions: [
        { q: 'How long is the warranty?', a: 'Warranty varies by brand, typically 2-5 years for luxury watches.' },
        { q: 'What does warranty cover?', a: 'Manufacturing defects, movement issues, and water resistance failure.' },
        { q: 'Where can I get my watch serviced?', a: 'At any TimeNest store or authorized service centers.' }
      ]
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Thank you for contacting us! We\'ll get back to you within 2 hours.');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <HelpCircle className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Contact Support</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            We're here to help with any questions or concerns about your TimeNest experience
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Contact Methods */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Get in Touch</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactMethods.map((method, index) => {
              const IconComponent = method.icon;
              return (
                <div key={index} className="bg-white rounded-2xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${
                    method.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                    method.color === 'green' ? 'bg-green-100 text-green-600' :
                    'bg-purple-100 text-purple-600'
                  }`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-gray-800 mb-2">{method.method}</h3>
                  <p className="font-semibold text-blue-600 mb-2">{method.details}</p>
                  <p className="text-sm text-gray-600 mb-2">{method.availability}</p>
                  <p className="text-xs text-gray-500">{method.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Support Form */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Send us a Message</h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                  <input
                    type="text"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                  <input
                    type="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Category *</label>
                  <select
                    name="category"
                    required
                    value={formData.category}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    {supportCategories.map((cat) => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {formData.category === 'order' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Order Number</label>
                  <input
                    type="text"
                    name="orderNumber"
                    value={formData.orderNumber}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="TN-2024-XXXXX"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Subject *</label>
                <input
                  type="text"
                  name="subject"
                  required
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message *</label>
                <textarea
                  name="message"
                  required
                  rows={5}
                  value={formData.message}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="Please describe your inquiry in detail..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-5 h-5" />
                Send Message
              </button>
            </form>
          </div>

          {/* FAQ Section */}
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Frequently Asked Questions</h2>
            <div className="space-y-6">
              {faqCategories.map((category, index) => (
                <div key={index} className="bg-white rounded-2xl shadow-lg p-6">
                  <h3 className="text-lg font-bold text-gray-800 mb-4">{category.category}</h3>
                  <div className="space-y-4">
                    {category.questions.map((faq, idx) => (
                      <div key={idx} className="border-b border-gray-100 pb-4 last:border-b-0">
                        <h4 className="font-semibold text-gray-800 mb-2">{faq.q}</h4>
                        <p className="text-gray-600 text-sm">{faq.a}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Store Locations for In-Person Support */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <h2 className="text-3xl font-bold text-center mb-8">Visit Our Stores</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <MapPin className="w-8 h-8 mx-auto mb-2" />
              <h4 className="font-semibold mb-1">Connaught Place</h4>
              <p className="text-sm text-blue-100">Mon-Sat: 10 AM - 9 PM</p>
            </div>
            <div className="text-center">
              <MapPin className="w-8 h-8 mx-auto mb-2" />
              <h4 className="font-semibold mb-1">Khan Market</h4>
              <p className="text-sm text-blue-100">Mon-Sat: 10:30 AM - 8:30 PM</p>
            </div>
            <div className="text-center">
              <MapPin className="w-8 h-8 mx-auto mb-2" />
              <h4 className="font-semibold mb-1">Gurgaon</h4>
              <p className="text-sm text-blue-100">Mon-Sun: 11 AM - 9 PM</p>
            </div>
            <div className="text-center">
              <MapPin className="w-8 h-8 mx-auto mb-2" />
              <h4 className="font-semibold mb-1">Mumbai</h4>
              <p className="text-sm text-blue-100">Mon-Sat: 10 AM - 10 PM</p>
            </div>
          </div>
          
          <div className="text-center mt-8">
            <button 
              onClick={() => onNavigate('stores')}
              className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors"
            >
              Find Store Near You
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactSupport;