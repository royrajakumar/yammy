import React from 'react';
import { ArrowLeft, Award, Users, Globe, Clock, Heart, Star } from 'lucide-react';
import { PageProps } from '../types/watch';

const AboutUs: React.FC<PageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-800 mb-6">
            About Time<span className="text-yellow-500">Nest</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Founded in 2010, TimeNest has been India's premier destination for luxury timepieces, 
            curating the finest watches from the world's most prestigious brands.
          </p>
        </div>

        {/* Story Section */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Our Story</h2>
            <div className="space-y-4 text-gray-600">
              <p>
                TimeNest began as a passion project by watch enthusiast Rajesh Sharma, who traveled 
                the world collecting rare and exceptional timepieces. What started as a personal 
                collection soon became a mission to bring the world's finest watches to India.
              </p>
              <p>
                Today, we're proud to be authorized dealers for 20 prestigious brands, offering 
                over 400 carefully curated timepieces. Each watch in our collection tells a story 
                of craftsmanship, innovation, and timeless elegance.
              </p>
              <p>
                Our commitment goes beyond selling watches – we're custodians of horological heritage, 
                ensuring every timepiece finds its perfect owner and receives the care it deserves.
              </p>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/1034063/pexels-photo-1034063.jpeg?auto=compress&cs=tinysrgb&w=600"
              alt="Luxury watch collection"
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -right-6 bg-yellow-500 text-white p-4 rounded-xl shadow-lg">
              <div className="text-2xl font-bold">14+</div>
              <div className="text-sm">Years of Excellence</div>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="bg-white rounded-3xl shadow-xl p-8 mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Our Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Authenticity</h3>
              <p className="text-gray-600">
                Every timepiece comes with a guarantee of authenticity. We work directly with 
                authorized distributors to ensure you receive genuine products.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Passion</h3>
              <p className="text-gray-600">
                Our team consists of watch enthusiasts who understand the emotional connection 
                between a person and their timepiece.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Excellence</h3>
              <p className="text-gray-600">
                From customer service to after-sales support, we strive for excellence in 
                every interaction and service we provide.
              </p>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          <div className="text-center">
            <div className="text-4xl font-bold text-blue-600 mb-2">400+</div>
            <div className="text-gray-600">Premium Watches</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-green-600 mb-2">20</div>
            <div className="text-gray-600">Luxury Brands</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-purple-600 mb-2">10,000+</div>
            <div className="text-gray-600">Happy Customers</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-yellow-600 mb-2">14</div>
            <div className="text-gray-600">Years Experience</div>
          </div>
        </div>

        {/* Team Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <h2 className="text-3xl font-bold text-center mb-8">Meet Our Team</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-12 h-12" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Rajesh Sharma</h3>
              <p className="text-blue-100">Founder & CEO</p>
              <p className="text-sm text-blue-100 mt-2">
                Watch collector with 25+ years of experience in luxury timepieces.
              </p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-12 h-12" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Priya Mehta</h3>
              <p className="text-blue-100">Head of Curation</p>
              <p className="text-sm text-blue-100 mt-2">
                Expert in Swiss and Japanese horology with certification from WOSTEP.
              </p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-12 h-12" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Arjun Patel</h3>
              <p className="text-blue-100">Customer Experience</p>
              <p className="text-sm text-blue-100 mt-2">
                Dedicated to ensuring every customer finds their perfect timepiece.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;