import React from 'react';
import { ArrowLeft, Shield, Clock, CheckCircle, AlertCircle, FileText, Phone } from 'lucide-react';
import { PageProps } from '../types/watch';

const WarrantyInfo: React.FC<PageProps> = ({ onNavigate }) => {
  const warrantyTypes = [
    {
      type: 'International Warranty',
      duration: '2-5 Years',
      coverage: 'Manufacturing defects, movement issues, water resistance failure',
      brands: ['Rolex', 'Omega', 'TAG Heuer', 'Breitling', 'IWC'],
      color: 'blue'
    },
    {
      type: 'Manufacturer Warranty',
      duration: '1-3 Years',
      coverage: 'Factory defects, component failure, accuracy issues',
      brands: ['Seiko', 'Citizen', 'Casio', 'Fossil', 'Tissot'],
      color: 'green'
    },
    {
      type: 'Extended Warranty',
      duration: 'Up to 10 Years',
      coverage: 'Comprehensive coverage including accidental damage',
      brands: ['Available for all premium brands'],
      color: 'purple'
    }
  ];

  const warrantyProcess = [
    {
      step: 1,
      title: 'Register Your Watch',
      description: 'Complete online registration within 30 days of purchase',
      icon: FileText
    },
    {
      step: 2,
      title: 'Report Issue',
      description: 'Contact our service center or visit any TimeNest store',
      icon: Phone
    },
    {
      step: 3,
      title: 'Assessment',
      description: 'Our certified technicians will evaluate your watch',
      icon: CheckCircle
    },
    {
      step: 4,
      title: 'Repair/Replace',
      description: 'Free repair or replacement under warranty terms',
      icon: Shield
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <Shield className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Warranty Information</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Comprehensive warranty coverage for your peace of mind
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Warranty Types */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Warranty Coverage</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {warrantyTypes.map((warranty, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-6 ${
                  warranty.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                  warranty.color === 'green' ? 'bg-green-100 text-green-600' :
                  'bg-purple-100 text-purple-600'
                }`}>
                  <Shield className="w-6 h-6" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-800 mb-2">{warranty.type}</h3>
                <div className="text-2xl font-bold text-blue-600 mb-4">{warranty.duration}</div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Coverage Includes:</h4>
                    <p className="text-gray-600 text-sm">{warranty.coverage}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Applicable Brands:</h4>
                    <div className="flex flex-wrap gap-1">
                      {warranty.brands.map((brand, idx) => (
                        <span key={idx} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                          {brand}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Warranty Process */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Warranty Claim Process</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {warrantyProcess.map((process, index) => {
              const IconComponent = process.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-blue-600" />
                  </div>
                  <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-sm font-bold">
                    {process.step}
                  </div>
                  <h3 className="font-semibold text-gray-800 mb-2">{process.title}</h3>
                  <p className="text-gray-600 text-sm">{process.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Important Information */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <div className="bg-green-50 border border-green-200 rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <h3 className="text-xl font-bold text-green-800">What's Covered</h3>
            </div>
            <ul className="space-y-2 text-green-700">
              <li>• Manufacturing defects</li>
              <li>• Movement malfunctions</li>
              <li>• Water resistance failure</li>
              <li>• Crown and pushers issues</li>
              <li>• Crystal defects</li>
              <li>• Bracelet/strap defects</li>
              <li>• Accuracy problems</li>
              <li>• Battery replacement (quartz)</li>
            </ul>
          </div>

          <div className="bg-red-50 border border-red-200 rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-4">
              <AlertCircle className="w-6 h-6 text-red-600" />
              <h3 className="text-xl font-bold text-red-800">What's Not Covered</h3>
            </div>
            <ul className="space-y-2 text-red-700">
              <li>• Physical damage from drops</li>
              <li>• Water damage from misuse</li>
              <li>• Scratches and wear</li>
              <li>• Damage from unauthorized repair</li>
              <li>• Battery leakage damage</li>
              <li>• Magnetic damage</li>
              <li>• Theft or loss</li>
              <li>• Expired warranty period</li>
            </ul>
          </div>
        </div>

        {/* Registration Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Register Your Watch</h2>
          <div className="max-w-2xl mx-auto">
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input type="email" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Watch Brand</label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    <option>Select Brand</option>
                    <option>Rolex</option>
                    <option>Omega</option>
                    <option>TAG Heuer</option>
                    <option>Seiko</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Model Name</label>
                  <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Serial Number</label>
                  <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Purchase Date</label>
                  <input type="date" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Purchase Location</label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                  <option>Select Store</option>
                  <option>TimeNest Flagship - Connaught Place</option>
                  <option>TimeNest Premium - Khan Market</option>
                  <option>TimeNest Select - Gurgaon</option>
                  <option>TimeNest Boutique - Mumbai</option>
                </select>
              </div>
              
              <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                Register Watch
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WarrantyInfo;