import React, { useState } from 'react';
import { ArrowLeft, Search, ChevronDown, ChevronUp, HelpCircle, ShoppingCart, Truck, RotateCcw, Shield, Wrench } from 'lucide-react';
import { PageProps } from '../types/watch';

const FAQ: React.FC<PageProps> = ({ onNavigate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);

  const faqCategories = [
    { id: 'all', name: 'All Questions', icon: HelpCircle },
    { id: 'ordering', name: 'Ordering', icon: ShoppingCart },
    { id: 'shipping', name: 'Shipping', icon: Truck },
    { id: 'returns', name: 'Returns', icon: RotateCcw },
    { id: 'warranty', name: 'Warranty', icon: Shield },
    { id: 'service', name: 'Service', icon: Wrench }
  ];

  const faqs = [
    {
      id: 1,
      category: 'ordering',
      question: 'How do I place an order?',
      answer: 'You can place an order by browsing our collection, adding items to your cart, and proceeding to checkout. You can also visit any of our stores or call our customer service at +91 11 2345 6789.'
    },
    {
      id: 2,
      category: 'ordering',
      question: 'What payment methods do you accept?',
      answer: 'We accept all major credit cards (Visa, MasterCard, American Express), debit cards, UPI, net banking, and EMI options. We also accept cash payments at our physical stores.'
    },
    {
      id: 3,
      category: 'ordering',
      question: 'Can I modify or cancel my order?',
      answer: 'Orders can be modified or cancelled within 1 hour of placement. After that, please contact our customer service team. Once the order is shipped, modifications are not possible.'
    },
    {
      id: 4,
      category: 'shipping',
      question: 'How long does shipping take?',
      answer: 'Standard shipping takes 3-5 business days, while express shipping takes 1-2 business days. Same-day delivery is available in Delhi NCR and Mumbai for orders placed before 2 PM.'
    },
    {
      id: 5,
      category: 'shipping',
      question: 'Do you offer free shipping?',
      answer: 'Yes, we offer free standard shipping on all orders above ₹25,000. For orders below this amount, shipping charges of ₹200 apply.'
    },
    {
      id: 6,
      category: 'shipping',
      question: 'Can I track my order?',
      answer: 'Absolutely! Once your order is shipped, you\'ll receive a tracking number via email and SMS. You can track your order on our website or the courier partner\'s website.'
    },
    {
      id: 7,
      category: 'shipping',
      question: 'Do you ship internationally?',
      answer: 'Currently, we only ship within India. International shipping is coming soon. Please subscribe to our newsletter to be notified when international shipping becomes available.'
    },
    {
      id: 8,
      category: 'returns',
      question: 'What is your return policy?',
      answer: 'We offer a 30-day return policy for unworn watches in original packaging with all accessories and documentation. The watch must be in pristine condition.'
    },
    {
      id: 9,
      category: 'returns',
      question: 'How do I return a watch?',
      answer: 'Contact our customer service team or visit any TimeNest store. We\'ll provide you with a return authorization and prepaid shipping label. You can also initiate returns through your account on our website.'
    },
    {
      id: 10,
      category: 'returns',
      question: 'Are there any return fees?',
      answer: 'Returns are free for defective or damaged items. For change of mind returns, a processing fee of ₹200 applies. This fee is waived for premium customers and orders above ₹1,00,000.'
    },
    {
      id: 11,
      category: 'returns',
      question: 'How long does it take to process a refund?',
      answer: 'Once we receive your returned item, refunds are processed within 5-7 business days. The amount will be credited to your original payment method.'
    },
    {
      id: 12,
      category: 'warranty',
      question: 'How long is the warranty on watches?',
      answer: 'Warranty periods vary by brand: Luxury brands (Rolex, Omega) offer 2-5 years, mid-range brands offer 1-3 years, and fashion brands offer 1-2 years. All warranties are international.'
    },
    {
      id: 13,
      category: 'warranty',
      question: 'What does the warranty cover?',
      answer: 'Warranty covers manufacturing defects, movement malfunctions, water resistance failure, and component defects. It does not cover damage from misuse, accidents, or normal wear and tear.'
    },
    {
      id: 14,
      category: 'warranty',
      question: 'How do I claim warranty?',
      answer: 'Contact our service center or visit any TimeNest store with your watch and warranty card. Our certified technicians will assess the issue and provide free repair or replacement if covered under warranty.'
    },
    {
      id: 15,
      category: 'warranty',
      question: 'Do I need to register my watch for warranty?',
      answer: 'Yes, we recommend registering your watch within 30 days of purchase for faster warranty claims and to receive service reminders and updates.'
    },
    {
      id: 16,
      category: 'service',
      question: 'Where can I get my watch serviced?',
      answer: 'You can get your watch serviced at any TimeNest store or authorized service centers. We have certified technicians trained by the respective watch brands.'
    },
    {
      id: 17,
      category: 'service',
      question: 'How much does watch servicing cost?',
      answer: 'Service costs vary by watch type and complexity: Basic service starts from ₹2,500, complete overhaul from ₹5,000, and luxury watch service from ₹10,000. We provide free estimates.'
    },
    {
      id: 18,
      category: 'service',
      question: 'How long does servicing take?',
      answer: 'Basic services take 7-14 days, complete overhauls take 3-4 weeks, and complex repairs may take 4-6 weeks. We provide regular updates on service progress.'
    },
    {
      id: 19,
      category: 'service',
      question: 'Do you service watches bought elsewhere?',
      answer: 'Yes, we service watches from all brands regardless of where they were purchased. However, warranty terms may differ for watches not purchased from TimeNest.'
    },
    {
      id: 20,
      category: 'ordering',
      question: 'Are your watches authentic?',
      answer: 'Absolutely! All our watches are 100% authentic and sourced directly from authorized distributors. Each watch comes with original warranty cards and documentation.'
    }
  ];

  const filteredFAQs = faqs.filter(faq => {
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    const matchesSearch = faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleFAQ = (id: number) => {
    setOpenFAQ(openFAQ === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <HelpCircle className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Find quick answers to common questions about TimeNest
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Search and Filter */}
        <div className="mb-12">
          <div className="max-w-2xl mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search frequently asked questions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-full focus:border-blue-500 focus:outline-none text-lg"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4">
            {faqCategories.map((category) => {
              const IconComponent = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-colors ${
                    selectedCategory === category.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <IconComponent className="w-5 h-5" />
                  {category.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* FAQ Results */}
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <p className="text-gray-600">
              Showing {filteredFAQs.length} of {faqs.length} questions
              {selectedCategory !== 'all' && ` in ${faqCategories.find(c => c.id === selectedCategory)?.name}`}
            </p>
          </div>

          {filteredFAQs.length > 0 ? (
            <div className="space-y-4">
              {filteredFAQs.map((faq) => (
                <div key={faq.id} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                  <button
                    onClick={() => toggleFAQ(faq.id)}
                    className="w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                  >
                    <h3 className="text-lg font-semibold text-gray-800 pr-4">{faq.question}</h3>
                    {openFAQ === faq.id ? (
                      <ChevronUp className="w-6 h-6 text-blue-600 flex-shrink-0" />
                    ) : (
                      <ChevronDown className="w-6 h-6 text-gray-400 flex-shrink-0" />
                    )}
                  </button>
                  
                  {openFAQ === faq.id && (
                    <div className="px-8 pb-6">
                      <div className="border-t pt-4">
                        <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <HelpCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-2xl font-semibold text-gray-800 mb-2">No questions found</h3>
              <p className="text-gray-600 mb-6">Try adjusting your search terms or category filter</p>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('all');
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full transition-colors"
              >
                Show All Questions
              </button>
            </div>
          )}
        </div>

        {/* Still Need Help */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Still Need Help?</h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Can't find the answer you're looking for? Our customer support team is here to help.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <HelpCircle className="w-6 h-6" />
                </div>
                <h4 className="font-semibold mb-1">Live Chat</h4>
                <p className="text-sm text-blue-100">Available 9 AM - 9 PM</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <ShoppingCart className="w-6 h-6" />
                </div>
                <h4 className="font-semibold mb-1">Phone Support</h4>
                <p className="text-sm text-blue-100">24/7 Customer Service</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Truck className="w-6 h-6" />
                </div>
                <h4 className="font-semibold mb-1">Visit Store</h4>
                <p className="text-sm text-blue-100">4 Locations Across India</p>
              </div>
            </div>
            
            <button 
              onClick={() => onNavigate('contact-support')}
              className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors"
            >
              Contact Support Team
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQ;