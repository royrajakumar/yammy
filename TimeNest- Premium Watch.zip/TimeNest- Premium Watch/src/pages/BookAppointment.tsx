import React, { useState } from 'react';
import { ArrowLeft, Calendar, Clock, MapPin, User, Phone, Mail, CheckCircle } from 'lucide-react';
import { PageProps } from '../types/watch';

const BookAppointment: React.FC<PageProps> = ({ onNavigate }) => {
  const [step, setStep] = useState(1);
  const [appointmentData, setAppointmentData] = useState({
    service: '',
    store: '',
    date: '',
    time: '',
    name: '',
    email: '',
    phone: '',
    watchBrand: '',
    watchModel: '',
    notes: ''
  });

  const services = [
    {
      id: 'consultation',
      name: 'Watch Consultation',
      description: 'Expert advice on watch selection and features',
      duration: '30 minutes',
      price: 'Free'
    },
    {
      id: 'sizing',
      name: 'Watch Sizing & Fitting',
      description: 'Professional sizing and strap adjustment',
      duration: '15 minutes',
      price: 'Free'
    },
    {
      id: 'service-estimate',
      name: 'Service Estimate',
      description: 'Evaluation and quote for watch repair/service',
      duration: '20 minutes',
      price: 'Free'
    },
    {
      id: 'authentication',
      name: 'Watch Authentication',
      description: 'Professional authentication service',
      duration: '45 minutes',
      price: '₹1,500'
    },
    {
      id: 'trade-in',
      name: 'Trade-in Evaluation',
      description: 'Assess your watch for trade-in value',
      duration: '30 minutes',
      price: 'Free'
    },
    {
      id: 'custom-order',
      name: 'Custom Order Discussion',
      description: 'Discuss custom watch orders and specifications',
      duration: '60 minutes',
      price: 'Free'
    }
  ];

  const stores = [
    {
      id: 'cp',
      name: 'TimeNest Flagship - Connaught Place',
      address: '123 Luxury Plaza, Connaught Place, New Delhi 110001',
      phone: '+91 11 2345 6789',
      hours: 'Mon-Sat: 10:00 AM - 9:00 PM, Sun: 11:00 AM - 8:00 PM'
    },
    {
      id: 'km',
      name: 'TimeNest Premium - Khan Market',
      address: '45 Khan Market, New Delhi 110003',
      phone: '+91 11 2345 6790',
      hours: 'Mon-Sat: 10:30 AM - 8:30 PM, Sun: 12:00 PM - 7:00 PM'
    },
    {
      id: 'ggn',
      name: 'TimeNest Select - Gurgaon',
      address: '78 DLF Cyber City, Gurgaon 122002',
      phone: '+91 124 2345 6791',
      hours: 'Mon-Sun: 11:00 AM - 9:00 PM'
    },
    {
      id: 'mumbai',
      name: 'TimeNest Boutique - Mumbai',
      address: '156 Linking Road, Bandra West, Mumbai 400050',
      phone: '+91 22 2345 6792',
      hours: 'Mon-Sat: 10:00 AM - 10:00 PM, Sun: 11:00 AM - 9:00 PM'
    }
  ];

  const timeSlots = [
    '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
    '12:00 PM', '12:30 PM', '2:00 PM', '2:30 PM',
    '3:00 PM', '3:30 PM', '4:00 PM', '4:30 PM',
    '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM',
    '7:00 PM', '7:30 PM', '8:00 PM'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setAppointmentData({
      ...appointmentData,
      [e.target.name]: e.target.value
    });
  };

  const handleNext = () => {
    setStep(step + 1);
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Appointment booked:', appointmentData);
    setStep(5); // Success step
  };

  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 30);
    return maxDate.toISOString().split('T')[0];
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <Calendar className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Book an Appointment</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Schedule a personalized consultation with our watch experts
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Progress Indicator */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="flex items-center justify-center">
            {[1, 2, 3, 4].map((stepNumber) => (
              <React.Fragment key={stepNumber}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                  step >= stepNumber ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {stepNumber}
                </div>
                {stepNumber < 4 && (
                  <div className={`w-16 h-1 ${
                    step > stepNumber ? 'bg-blue-600' : 'bg-gray-200'
                  }`}></div>
                )}
              </React.Fragment>
            ))}
          </div>
          <div className="flex justify-between mt-4 text-sm text-gray-600">
            <span>Service</span>
            <span>Store & Time</span>
            <span>Details</span>
            <span>Confirm</span>
          </div>
        </div>

        <div className="max-w-2xl mx-auto">
          {/* Step 1: Select Service */}
          {step === 1 && (
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Select Service</h2>
              <div className="space-y-4">
                {services.map((service) => (
                  <label key={service.id} className="block">
                    <input
                      type="radio"
                      name="service"
                      value={service.id}
                      onChange={handleInputChange}
                      className="sr-only"
                    />
                    <div className={`p-6 border-2 rounded-xl cursor-pointer transition-colors ${
                      appointmentData.service === service.id
                        ? 'border-blue-600 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold text-gray-800">{service.name}</h3>
                        <span className="text-blue-600 font-semibold">{service.price}</span>
                      </div>
                      <p className="text-gray-600 text-sm mb-2">{service.description}</p>
                      <p className="text-gray-500 text-xs">Duration: {service.duration}</p>
                    </div>
                  </label>
                ))}
              </div>
              <div className="flex justify-end mt-8">
                <button
                  onClick={handleNext}
                  disabled={!appointmentData.service}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Select Store and Time */}
          {step === 2 && (
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Select Store & Time</h2>
              
              {/* Store Selection */}
              <div className="mb-8">
                <h3 className="font-semibold text-gray-800 mb-4">Choose Store</h3>
                <div className="space-y-4">
                  {stores.map((store) => (
                    <label key={store.id} className="block">
                      <input
                        type="radio"
                        name="store"
                        value={store.id}
                        onChange={handleInputChange}
                        className="sr-only"
                      />
                      <div className={`p-4 border-2 rounded-xl cursor-pointer transition-colors ${
                        appointmentData.store === store.id
                          ? 'border-blue-600 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}>
                        <h4 className="font-semibold text-gray-800">{store.name}</h4>
                        <p className="text-gray-600 text-sm">{store.address}</p>
                        <p className="text-gray-500 text-xs">{store.hours}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Date and Time Selection */}
              {appointmentData.store && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Select Date</label>
                    <input
                      type="date"
                      name="date"
                      value={appointmentData.date}
                      onChange={handleInputChange}
                      min={getMinDate()}
                      max={getMaxDate()}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  {appointmentData.date && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Select Time</label>
                      <div className="grid grid-cols-4 gap-3">
                        {timeSlots.map((time) => (
                          <label key={time} className="block">
                            <input
                              type="radio"
                              name="time"
                              value={time}
                              onChange={handleInputChange}
                              className="sr-only"
                            />
                            <div className={`p-3 text-center border-2 rounded-lg cursor-pointer transition-colors text-sm ${
                              appointmentData.time === time
                                ? 'border-blue-600 bg-blue-50 text-blue-600'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}>
                              {time}
                            </div>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="flex justify-between mt-8">
                <button
                  onClick={handleBack}
                  className="border border-gray-300 text-gray-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-50"
                >
                  Back
                </button>
                <button
                  onClick={handleNext}
                  disabled={!appointmentData.store || !appointmentData.date || !appointmentData.time}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Personal Details */}
          {step === 3 && (
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Details</h2>
              
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={appointmentData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={appointmentData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                  <input
                    type="tel"
                    name="phone"
                    required
                    value={appointmentData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Watch Brand (if applicable)</label>
                    <input
                      type="text"
                      name="watchBrand"
                      value={appointmentData.watchBrand}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Watch Model (if applicable)</label>
                    <input
                      type="text"
                      name="watchModel"
                      value={appointmentData.watchModel}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Additional Notes</label>
                  <textarea
                    name="notes"
                    rows={4}
                    value={appointmentData.notes}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="Any specific requirements or questions..."
                  ></textarea>
                </div>
              
              </form>

              <div className="flex justify-between mt-8">
                <button
                  onClick={handleBack}
                  className="border border-gray-300 text-gray-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-50"
                >
                  Back
                </button>
                <button
                  onClick={handleNext}
                  disabled={!appointmentData.name || !appointmentData.email || !appointmentData.phone}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Review
                </button>
              </div>
            </div>
          )}

          {/* Step 4: Confirmation */}
          {step === 4 && (
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Confirm Appointment</h2>
              
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-xl p-6">
                  <h3 className="font-semibold text-gray-800 mb-4">Appointment Summary</h3>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Service:</span>
                      <span className="font-medium">
                        {services.find(s => s.id === appointmentData.service)?.name}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Store:</span>
                      <span className="font-medium">
                        {stores.find(s => s.id === appointmentData.store)?.name}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Date & Time:</span>
                      <span className="font-medium">
                        {appointmentData.date} at {appointmentData.time}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Duration:</span>
                      <span className="font-medium">
                        {services.find(s => s.id === appointmentData.service)?.duration}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Cost:</span>
                      <span className="font-medium">
                        {services.find(s => s.id === appointmentData.service)?.price}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-xl p-6">
                  <h3 className="font-semibold text-gray-800 mb-4">Contact Information</h3>
                  <div className="space-y-2">
                    <p><span className="text-gray-600">Name:</span> {appointmentData.name}</p>
                    <p><span className="text-gray-600">Email:</span> {appointmentData.email}</p>
                    <p><span className="text-gray-600">Phone:</span> {appointmentData.phone}</p>
                    {appointmentData.watchBrand && (
                      <p><span className="text-gray-600">Watch:</span> {appointmentData.watchBrand} {appointmentData.watchModel}</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-between mt-8">
                <button
                  onClick={handleBack}
                  className="border border-gray-300 text-gray-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-50"
                >
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700"
                >
                  Confirm Appointment
                </button>
              </div>
            </div>
          )}

          {/* Step 5: Success */}
          {step === 5 && (
            <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Appointment Confirmed!</h2>
              <p className="text-gray-600 mb-8">
                Your appointment has been successfully booked. You'll receive a confirmation email shortly.
              </p>
              
              <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-8">
                <h3 className="font-semibold text-green-800 mb-2">Appointment Reference: TN-APT-2024-001</h3>
                <p className="text-green-700 text-sm">
                  Please arrive 10 minutes early and bring a valid ID. If you need to reschedule, 
                  please contact us at least 24 hours in advance.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => onNavigate('home')}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700"
                >
                  Back to Home
                </button>
                <button
                  onClick={() => setStep(1)}
                  className="border border-blue-600 text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50"
                >
                  Book Another Appointment
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookAppointment;