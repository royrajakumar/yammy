import React, { useState, useRef, useEffect } from 'react';
import { ArrowLeft, MessageCircle, Send, User, Bot, Clock, Phone, Mail, Minimize2, Maximize2 } from 'lucide-react';
import { PageProps } from '../types/watch';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'agent' | 'bot';
  timestamp: Date;
  senderName?: string;
}

const LiveChat: React.FC<PageProps> = ({ onNavigate }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! Welcome to TimeNest. I'm Sarah, your customer support agent. How can I help you today?",
      sender: 'agent',
      timestamp: new Date(),
      senderName: 'Sarah'
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatStatus, setChatStatus] = useState<'connecting' | 'connected' | 'offline'>('connected');
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickReplies = [
    "I need help with my order",
    "Product information",
    "Shipping details",
    "Return/Exchange",
    "Payment issues",
    "Warranty information"
  ];

  const agentInfo = {
    name: 'Sarah Johnson',
    role: 'Senior Customer Support',
    avatar: '👩‍💼',
    status: 'online',
    responseTime: '< 2 minutes'
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const userMessage: Message = {
        id: messages.length + 1,
        text: newMessage,
        sender: 'user',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, userMessage]);
      setNewMessage('');
      setIsTyping(true);

      // Simulate agent response
      setTimeout(() => {
        const agentResponse: Message = {
          id: messages.length + 2,
          text: getAgentResponse(newMessage),
          sender: 'agent',
          timestamp: new Date(),
          senderName: 'Sarah'
        };
        setMessages(prev => [...prev, agentResponse]);
        setIsTyping(false);
      }, 1500);
    }
  };

  const getAgentResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('order') || message.includes('track')) {
      return "I'd be happy to help you with your order. Could you please provide your order number? It should start with 'TN-2024-'.";
    } else if (message.includes('product') || message.includes('watch')) {
      return "I can help you with product information. Are you looking for a specific brand or type of watch? We have luxury, sport, classic, and smart watches available.";
    } else if (message.includes('shipping') || message.includes('delivery')) {
      return "For shipping information: We offer free shipping on orders above ₹25,000. Standard delivery takes 3-5 days, express delivery 1-2 days. Would you like specific delivery details for your location?";
    } else if (message.includes('return') || message.includes('exchange')) {
      return "Our return policy allows returns within 30 days for unworn watches in original packaging. Would you like to initiate a return or need more information about our return process?";
    } else if (message.includes('payment') || message.includes('pay')) {
      return "We accept all major payment methods including credit/debit cards, UPI, net banking, and EMI options. Is there a specific payment issue you're facing?";
    } else if (message.includes('warranty')) {
      return "Warranty varies by brand - typically 2-5 years for luxury watches. All our watches come with international warranty. Do you need warranty information for a specific watch?";
    } else {
      return "Thank you for your message. I'm here to help with any questions about our watches, orders, shipping, returns, or any other concerns. How can I assist you further?";
    }
  };

  const handleQuickReply = (reply: string) => {
    setNewMessage(reply);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-IN', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <MessageCircle className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Live Chat Support</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Get instant help from our customer support team
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Chat Interface */}
          <div className="lg:col-span-3">
            <div className={`bg-white rounded-2xl shadow-xl overflow-hidden transition-all duration-300 ${
              isMinimized ? 'h-20' : 'h-[600px]'
            }`}>
              {/* Chat Header */}
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                      <span className="text-lg">{agentInfo.avatar}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold">{agentInfo.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-blue-100">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        <span>{agentInfo.status}</span>
                        <span>•</span>
                        <span>Responds in {agentInfo.responseTime}</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsMinimized(!isMinimized)}
                    className="p-2 hover:bg-white/20 rounded-full transition-colors"
                  >
                    {isMinimized ? <Maximize2 className="w-5 h-5" /> : <Minimize2 className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {!isMinimized && (
                <>
                  {/* Messages Area */}
                  <div className="flex-1 p-4 h-96 overflow-y-auto bg-gray-50">
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                            message.sender === 'user'
                              ? 'bg-blue-600 text-white'
                              : 'bg-white text-gray-800 shadow-sm'
                          }`}>
                            {message.sender !== 'user' && (
                              <div className="text-xs text-gray-500 mb-1">{message.senderName}</div>
                            )}
                            <p className="text-sm">{message.text}</p>
                            <div className={`text-xs mt-1 ${
                              message.sender === 'user' ? 'text-blue-100' : 'text-gray-400'
                            }`}>
                              {formatTime(message.timestamp)}
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      {isTyping && (
                        <div className="flex justify-start">
                          <div className="bg-white text-gray-800 shadow-sm px-4 py-2 rounded-2xl">
                            <div className="flex items-center gap-1">
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
                            </div>
                          </div>
                        </div>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                  </div>

                  {/* Quick Replies */}
                  <div className="px-4 py-2 bg-gray-100 border-t">
                    <div className="flex flex-wrap gap-2">
                      {quickReplies.map((reply, index) => (
                        <button
                          key={index}
                          onClick={() => handleQuickReply(reply)}
                          className="px-3 py-1 bg-white text-gray-600 rounded-full text-sm hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        >
                          {reply}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Message Input */}
                  <div className="p-4 border-t bg-white">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        placeholder="Type your message..."
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                      <button
                        onClick={handleSendMessage}
                        disabled={!newMessage.trim()}
                        className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        <Send className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Support Info Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Agent Info */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="font-bold text-gray-800 mb-4">Your Support Agent</h3>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">{agentInfo.avatar}</span>
                </div>
                <div>
                  <div className="font-semibold text-gray-800">{agentInfo.name}</div>
                  <div className="text-sm text-gray-600">{agentInfo.role}</div>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-600">Online now</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">Avg response: {agentInfo.responseTime}</span>
                </div>
              </div>
            </div>

            {/* Alternative Contact */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="font-bold text-gray-800 mb-4">Other Ways to Reach Us</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <Phone className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-gray-800">Phone Support</div>
                    <div className="text-sm text-gray-600">+91 11 2345 6789</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Mail className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-gray-800">Email Support</div>
                    <div className="text-sm text-gray-600">support@timenest.com</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Support Hours */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="font-bold text-gray-800 mb-4">Support Hours</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Live Chat:</span>
                  <span className="font-medium">24/7</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Phone:</span>
                  <span className="font-medium">9 AM - 9 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Email:</span>
                  <span className="font-medium">24/7</span>
                </div>
              </div>
            </div>

            {/* FAQ Link */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl text-white p-6">
              <h3 className="font-bold mb-2">Need Quick Answers?</h3>
              <p className="text-sm text-blue-100 mb-4">
                Check our FAQ section for instant answers to common questions.
              </p>
              <button 
                onClick={() => onNavigate('faq')}
                className="bg-white text-blue-600 px-4 py-2 rounded-full text-sm font-semibold hover:bg-gray-100 transition-colors"
              >
                View FAQ
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveChat;