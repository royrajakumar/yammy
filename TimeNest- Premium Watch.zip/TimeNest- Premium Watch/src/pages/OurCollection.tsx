import React, { useState } from 'react';
import { ArrowLeft, Filter, Grid, List, Search } from 'lucide-react';
import { PageProps } from '../types/watch';
import { watches, brands } from '../data/watches';
import WatchCard from '../components/WatchCard';

const OurCollection: React.FC<PageProps> = ({ onNavigate }) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredWatches = watches.filter(watch => {
    const matchesSearch = watch.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         watch.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = selectedBrand === 'all' || watch.brand === selectedBrand;
    const matchesCategory = selectedCategory === 'all' || watch.category === selectedCategory;
    
    return matchesSearch && matchesBrand && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-5xl font-bold mb-4">Our Complete Collection</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Explore 400+ carefully curated timepieces from the world's most prestigious brands
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border-b sticky top-0 z-40">
        <div className="container mx-auto px-6 py-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex flex-wrap gap-4 items-center">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search watches..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500 w-64"
                />
              </div>

              {/* Brand Filter */}
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Brands</option>
                {brands.map(brand => (
                  <option key={brand.name} value={brand.name}>{brand.name}</option>
                ))}
              </select>

              {/* Category Filter */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Categories</option>
                <option value="luxury">Luxury</option>
                <option value="sport">Sport</option>
                <option value="classic">Classic</option>
                <option value="smart">Smart</option>
              </select>
            </div>

            {/* View Toggle */}
            <div className="flex items-center gap-2 bg-gray-100 rounded-full p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-full transition-colors ${
                  viewMode === 'grid' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                }`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-full transition-colors ${
                  viewMode === 'list' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                }`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Collection Stats */}
      <div className="container mx-auto px-6 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold text-blue-600">{filteredWatches.length}</div>
              <div className="text-gray-600">Watches Found</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600">
                {new Set(filteredWatches.map(w => w.brand)).size}
              </div>
              <div className="text-gray-600">Brands</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-600">
                ₹{Math.min(...filteredWatches.map(w => w.price)).toLocaleString()}
              </div>
              <div className="text-gray-600">Starting Price</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-yellow-600">
                ₹{Math.max(...filteredWatches.map(w => w.price)).toLocaleString()}
              </div>
              <div className="text-gray-600">Highest Price</div>
            </div>
          </div>
        </div>

        {/* Watch Grid */}
        <div className={`grid gap-6 ${
          viewMode === 'grid' 
            ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
            : 'grid-cols-1'
        }`}>
          {filteredWatches.map(watch => (
            <WatchCard key={watch.id} watch={watch} />
          ))}
        </div>

        {filteredWatches.length === 0 && (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">⌚</div>
            <h3 className="text-2xl font-semibold text-gray-800 mb-2">No watches found</h3>
            <p className="text-gray-600">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default OurCollection;