import React, { useState } from 'react';
import { ArrowLeft, Truck, Clock, MapPin, Package, Shield, Zap, CheckCircle, AlertCircle, Calculator } from 'lucide-react';
import { PageProps } from '../types/watch';

const ShippingInfo: React.FC<PageProps> = ({ onNavigate }) => {
  const [selectedCity, setSelectedCity] = useState('delhi');
  const [orderValue, setOrderValue] = useState(25000);

  const shippingOptions = [
    {
      type: 'Standard Shipping',
      icon: Truck,
      duration: '3-5 Business Days',
      cost: 'Free above ₹25,000',
      costBelow: '₹200',
      description: 'Reliable delivery through our trusted courier partners',
      features: ['Tracking included', 'Insurance covered', 'Signature required'],
      color: 'blue'
    },
    {
      type: 'Express Shipping',
      icon: Zap,
      duration: '1-2 Business Days',
      cost: '₹500',
      costBelow: '₹500',
      description: 'Fast delivery for urgent orders',
      features: ['Priority handling', 'Real-time tracking', 'SMS updates'],
      color: 'green'
    },
    {
      type: 'Same Day Delivery',
      icon: Clock,
      duration: 'Within 6 Hours',
      cost: '₹1,000',
      costBelow: '₹1,000',
      description: 'Available in Delhi NCR and Mumbai (orders before 2 PM)',
      features: ['Instant delivery', 'Live tracking', 'Direct handover'],
      color: 'purple'
    },
    {
      type: 'Store Pickup',
      icon: MapPin,
      duration: 'Ready in 2 Hours',
      cost: 'Free',
      costBelow: 'Free',
      description: 'Collect from any TimeNest store',
      features: ['No shipping cost', 'Personal assistance', 'Immediate availability'],
      color: 'orange'
    }
  ];

  const deliveryZones = [
    {
      zone: 'Metro Cities',
      cities: ['Delhi NCR', 'Mumbai', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad'],
      standard: '3-4 days',
      express: '1-2 days',
      sameDay: 'Available'
    },
    {
      zone: 'Tier 1 Cities',
      cities: ['Pune', 'Ahmedabad', 'Jaipur', 'Lucknow', 'Kanpur', 'Nagpur'],
      standard: '4-5 days',
      express: '2-3 days',
      sameDay: 'Not Available'
    },
    {
      zone: 'Tier 2 Cities',
      cities: ['Indore', 'Bhopal', 'Coimbatore', 'Kochi', 'Vadodara', 'Agra'],
      standard: '5-6 days',
      express: '3-4 days',
      sameDay: 'Not Available'
    },
    {
      zone: 'Other Areas',
      cities: ['Remote locations', 'Hill stations', 'Island territories'],
      standard: '6-8 days',
      express: '4-6 days',
      sameDay: 'Not Available'
    }
  ];

  const packagingFeatures = [
    {
      icon: Shield,
      title: 'Secure Packaging',
      description: 'Premium watch boxes with protective foam inserts'
    },
    {
      icon: Package,
      title: 'Luxury Presentation',
      description: 'Elegant TimeNest branded packaging for gifts'
    },
    {
      icon: CheckCircle,
      title: 'Quality Assurance',
      description: 'Each package inspected before dispatch'
    },
    {
      icon: Truck,
      title: 'Tamper-Proof',
      description: 'Sealed packaging with security features'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-100 text-blue-600',
      green: 'bg-green-100 text-green-600',
      purple: 'bg-purple-100 text-purple-600',
      orange: 'bg-orange-100 text-orange-600'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const calculateShipping = () => {
    if (orderValue >= 25000) return 0;
    return 200;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <Truck className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Shipping Information</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Fast, secure, and reliable delivery across India
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Shipping Calculator */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-12">
          <div className="flex items-center gap-3 mb-6">
            <Calculator className="w-6 h-6 text-blue-600" />
            <h2 className="text-2xl font-bold text-gray-800">Shipping Calculator</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Order Value</label>
              <input
                type="number"
                value={orderValue}
                onChange={(e) => setOrderValue(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="Enter order value"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Delivery Location</label>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="delhi">Delhi NCR</option>
                <option value="mumbai">Mumbai</option>
                <option value="bangalore">Bangalore</option>
                <option value="tier1">Tier 1 Cities</option>
                <option value="tier2">Tier 2 Cities</option>
                <option value="other">Other Areas</option>
              </select>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-blue-50 rounded-xl">
            <div className="flex justify-between items-center">
              <span className="font-semibold text-gray-800">Shipping Cost:</span>
              <span className="text-2xl font-bold text-blue-600">
                {calculateShipping() === 0 ? 'FREE' : `₹${calculateShipping()}`}
              </span>
            </div>
            {orderValue < 25000 && (
              <p className="text-sm text-gray-600 mt-2">
                Add ₹{(25000 - orderValue).toLocaleString()} more for free shipping!
              </p>
            )}
          </div>
        </div>

        {/* Shipping Options */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Shipping Options</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {shippingOptions.map((option, index) => {
              const IconComponent = option.icon;
              return (
                <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${getColorClasses(option.color)}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{option.type}</h3>
                  <div className="text-lg font-semibold text-blue-600 mb-2">{option.duration}</div>
                  
                  <div className="mb-4">
                    <div className="font-semibold text-green-600">{option.cost}</div>
                    {option.costBelow !== option.cost && (
                      <div className="text-sm text-gray-500">Below ₹25,000: {option.costBelow}</div>
                    )}
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-4">{option.description}</p>
                  
                  <div className="space-y-2">
                    {option.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Delivery Zones */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Delivery Zones & Timeline</h2>
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Zone</th>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Cities</th>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Standard</th>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Express</th>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Same Day</th>
                  </tr>
                </thead>
                <tbody>
                  {deliveryZones.map((zone, index) => (
                    <tr key={index} className="border-t hover:bg-gray-50">
                      <td className="px-6 py-4 font-semibold text-blue-600">{zone.zone}</td>
                      <td className="px-6 py-4 text-gray-600">
                        <div className="flex flex-wrap gap-1">
                          {zone.cities.slice(0, 3).map((city, idx) => (
                            <span key={idx} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                              {city}
                            </span>
                          ))}
                          {zone.cities.length > 3 && (
                            <span className="text-gray-500 text-xs">+{zone.cities.length - 3} more</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-600">{zone.standard}</td>
                      <td className="px-6 py-4 text-gray-600">{zone.express}</td>
                      <td className="px-6 py-4">
                        {zone.sameDay === 'Available' ? (
                          <span className="text-green-600 font-medium">✓ Available</span>
                        ) : (
                          <span className="text-gray-400">Not Available</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Packaging Features */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Premium Packaging</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {packagingFeatures.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div key={index} className="bg-white rounded-2xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-gray-800 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Important Notes */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-8">
          <div className="flex items-center gap-3 mb-4">
            <AlertCircle className="w-6 h-6 text-yellow-600" />
            <h3 className="text-xl font-bold text-yellow-800">Important Shipping Notes</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-6 text-yellow-700">
            <ul className="space-y-2">
              <li>• Orders placed before 2 PM are processed the same day</li>
              <li>• Weekend orders are processed on the next business day</li>
              <li>• Remote areas may require additional 1-2 days</li>
              <li>• Signature required for all luxury watch deliveries</li>
            </ul>
            <ul className="space-y-2">
              <li>• Free shipping applies to the total order value</li>
              <li>• Express shipping available for most locations</li>
              <li>• Same day delivery limited to select cities</li>
              <li>• International shipping coming soon</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShippingInfo;