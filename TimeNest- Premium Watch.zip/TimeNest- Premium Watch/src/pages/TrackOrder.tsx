import React, { useState } from 'react';
import { ArrowLeft, Package, Truck, CheckCircle, Clock, MapPin, Phone, Mail, Search, Calendar, User } from 'lucide-react';
import { PageProps } from '../types/watch';

const TrackOrder: React.FC<PageProps> = ({ onNavigate }) => {
  const [orderNumber, setOrderNumber] = useState('');
  const [email, setEmail] = useState('');
  const [trackingData, setTrackingData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Mock tracking data
  const mockTrackingData = {
    orderNumber: 'TN-2024-001234',
    status: 'In Transit',
    estimatedDelivery: '2024-01-25',
    currentLocation: 'Delhi Sorting Facility',
    items: [
      {
        name: 'Rolex Submariner Professional',
        image: 'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&w=200',
        price: '₹8,50,000',
        quantity: 1
      }
    ],
    timeline: [
      {
        status: 'Order Placed',
        date: '2024-01-20',
        time: '10:30 AM',
        location: 'TimeNest Store - CP',
        completed: true,
        description: 'Your order has been confirmed and payment processed'
      },
      {
        status: 'Processing',
        date: '2024-01-21',
        time: '2:15 PM',
        location: 'TimeNest Warehouse',
        completed: true,
        description: 'Order is being prepared for shipment'
      },
      {
        status: 'Shipped',
        date: '2024-01-22',
        time: '9:45 AM',
        location: 'Delhi Distribution Center',
        completed: true,
        description: 'Package has been dispatched via BlueDart Express'
      },
      {
        status: 'In Transit',
        date: '2024-01-23',
        time: '6:20 PM',
        location: 'Delhi Sorting Facility',
        completed: true,
        description: 'Package is on the way to your delivery address'
      },
      {
        status: 'Out for Delivery',
        date: '2024-01-25',
        time: 'Expected',
        location: 'Local Delivery Hub',
        completed: false,
        description: 'Package will be delivered today between 10 AM - 6 PM'
      },
      {
        status: 'Delivered',
        date: '2024-01-25',
        time: 'Pending',
        location: 'Your Address',
        completed: false,
        description: 'Package delivered and signed for'
      }
    ],
    shippingAddress: {
      name: 'Rajesh Kumar',
      address: '123 Green Park, New Delhi 110016',
      phone: '+91 98765 43210'
    },
    carrier: {
      name: 'BlueDart Express',
      trackingNumber: 'BD123456789IN',
      phone: '1860-233-1234'
    }
  };

  const handleTrackOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      if (orderNumber.toLowerCase().includes('tn-2024') || orderNumber === '001234') {
        setTrackingData(mockTrackingData);
      } else {
        setTrackingData(null);
        alert('Order not found. Please check your order number and email.');
      }
      setIsLoading(false);
    }, 1500);
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'delivered': return 'text-green-600 bg-green-100';
      case 'in transit': case 'shipped': return 'text-blue-600 bg-blue-100';
      case 'processing': return 'text-yellow-600 bg-yellow-100';
      case 'cancelled': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <Package className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Track Your Order</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Enter your order details to get real-time tracking information
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {!trackingData ? (
          /* Tracking Form */
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Enter Order Information</h2>
              
              <form onSubmit={handleTrackOrder} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Order Number *
                  </label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="text"
                      required
                      value={orderNumber}
                      onChange={(e) => setOrderNumber(e.target.value)}
                      placeholder="TN-2024-XXXXXX"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    You can find this in your order confirmation email
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your.email@example.com"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Tracking...
                    </>
                  ) : (
                    <>
                      <Package className="w-5 h-5" />
                      Track Order
                    </>
                  )}
                </button>
              </form>

              <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold text-blue-800 mb-2">Need Help?</h3>
                <p className="text-blue-700 text-sm mb-3">
                  Can't find your order number or having trouble tracking?
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <button 
                    onClick={() => onNavigate('contact-support')}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors"
                  >
                    Contact Support
                  </button>
                  <button className="border border-blue-600 text-blue-600 px-4 py-2 rounded-lg text-sm hover:bg-blue-50 transition-colors">
                    Call: +91 11 2345 6789
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Tracking Results */
          <div className="space-y-8">
            {/* Order Summary */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-800 mb-2">Order #{trackingData.orderNumber}</h2>
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(trackingData.status)}`}>
                    <div className="w-2 h-2 bg-current rounded-full mr-2"></div>
                    {trackingData.status}
                  </div>
                </div>
                <div className="text-right mt-4 lg:mt-0">
                  <p className="text-gray-600">Estimated Delivery</p>
                  <p className="text-xl font-bold text-blue-600">{trackingData.estimatedDelivery}</p>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <h3 className="font-semibold text-gray-800">Current Location</h3>
                  </div>
                  <p className="text-gray-600">{trackingData.currentLocation}</p>
                </div>
                
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <Truck className="w-5 h-5 text-green-600" />
                    <h3 className="font-semibold text-gray-800">Carrier</h3>
                  </div>
                  <p className="text-gray-600">{trackingData.carrier.name}</p>
                  <p className="text-sm text-gray-500">{trackingData.carrier.trackingNumber}</p>
                </div>
                
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <User className="w-5 h-5 text-purple-600" />
                    <h3 className="font-semibold text-gray-800">Delivery To</h3>
                  </div>
                  <p className="text-gray-600">{trackingData.shippingAddress.name}</p>
                  <p className="text-sm text-gray-500">{trackingData.shippingAddress.address}</p>
                </div>
              </div>
            </div>

            {/* Order Items */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-xl font-bold text-gray-800 mb-6">Order Items</h3>
              <div className="space-y-4">
                {trackingData.items.map((item: any, index: number) => (
                  <div key={index} className="flex items-center gap-4 p-4 border border-gray-200 rounded-xl">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-800">{item.name}</h4>
                      <p className="text-gray-600">Quantity: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-blue-600">{item.price}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tracking Timeline */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-xl font-bold text-gray-800 mb-6">Tracking Timeline</h3>
              <div className="space-y-6">
                {trackingData.timeline.map((event: any, index: number) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        event.completed ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-400'
                      }`}>
                        {event.completed ? (
                          <CheckCircle className="w-5 h-5" />
                        ) : (
                          <Clock className="w-5 h-5" />
                        )}
                      </div>
                      {index < trackingData.timeline.length - 1 && (
                        <div className={`w-0.5 h-16 ${event.completed ? 'bg-green-600' : 'bg-gray-200'}`}></div>
                      )}
                    </div>
                    
                    <div className="flex-1 pb-8">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                        <h4 className={`font-semibold ${event.completed ? 'text-gray-800' : 'text-gray-500'}`}>
                          {event.status}
                        </h4>
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {event.date}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {event.time}
                          </span>
                        </div>
                      </div>
                      <p className={`text-sm ${event.completed ? 'text-gray-600' : 'text-gray-400'} mb-1`}>
                        {event.description}
                      </p>
                      <p className={`text-xs ${event.completed ? 'text-gray-500' : 'text-gray-400'}`}>
                        {event.location}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl text-white p-8">
              <h3 className="text-xl font-bold mb-4">Need Assistance?</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <button 
                  onClick={() => onNavigate('contact-support')}
                  className="bg-white/20 hover:bg-white/30 text-white p-4 rounded-xl transition-colors text-center"
                >
                  <Phone className="w-6 h-6 mx-auto mb-2" />
                  <div className="font-semibold">Contact Support</div>
                  <div className="text-sm text-blue-100">Get help with your order</div>
                </button>
                
                <button className="bg-white/20 hover:bg-white/30 text-white p-4 rounded-xl transition-colors text-center">
                  <MapPin className="w-6 h-6 mx-auto mb-2" />
                  <div className="font-semibold">Change Address</div>
                  <div className="text-sm text-blue-100">Update delivery location</div>
                </button>
                
                <button 
                  onClick={() => setTrackingData(null)}
                  className="bg-white/20 hover:bg-white/30 text-white p-4 rounded-xl transition-colors text-center"
                >
                  <Search className="w-6 h-6 mx-auto mb-2" />
                  <div className="font-semibold">Track Another</div>
                  <div className="text-sm text-blue-100">Search different order</div>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TrackOrder;