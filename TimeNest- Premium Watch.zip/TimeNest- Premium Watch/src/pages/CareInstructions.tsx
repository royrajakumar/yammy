import React, { useState } from 'react';
import { ArrowLeft, Droplets, Sun, Shield, Wrench, AlertTriangle, CheckCircle } from 'lucide-react';
import { PageProps } from '../types/watch';

const CareInstructions: React.FC<PageProps> = ({ onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState<'daily' | 'cleaning' | 'storage' | 'maintenance'>('daily');

  const careCategories = {
    daily: {
      title: 'Daily Care',
      icon: Sun,
      tips: [
        {
          title: 'Avoid Extreme Temperatures',
          description: 'Keep your watch away from extreme heat or cold to prevent damage to internal components',
          icon: Sun,
          importance: 'high'
        },
        {
          title: 'Protect from Impacts',
          description: 'Remove your watch during sports or activities that might cause impacts or vibrations',
          icon: Shield,
          importance: 'high'
        },
        {
          title: 'Crown Position',
          description: 'Always ensure the crown is properly screwed down or pushed in to maintain water resistance',
          icon: CheckCircle,
          importance: 'medium'
        },
        {
          title: 'Regular Wearing',
          description: 'Automatic watches benefit from regular wearing to keep the movement lubricated',
          icon: CheckCircle,
          importance: 'low'
        }
      ]
    },
    cleaning: {
      title: 'Cleaning Guide',
      icon: Droplets,
      tips: [
        {
          title: 'Daily Cleaning',
          description: 'Wipe with a soft, dry cloth after each wear to remove oils and moisture',
          icon: Droplets,
          importance: 'medium'
        },
        {
          title: 'Deep Cleaning',
          description: 'Use a soft brush with mild soap and water for metal bracelets (if water resistant)',
          icon: Droplets,
          importance: 'medium'
        },
        {
          title: 'Leather Strap Care',
          description: 'Keep leather straps dry and condition them monthly with leather conditioner',
          icon: AlertTriangle,
          importance: 'high'
        },
        {
          title: 'Crystal Cleaning',
          description: 'Use a microfiber cloth to clean the crystal without scratching',
          icon: CheckCircle,
          importance: 'low'
        }
      ]
    },
    storage: {
      title: 'Storage Tips',
      icon: Shield,
      tips: [
        {
          title: 'Watch Box Storage',
          description: 'Store in a dedicated watch box with soft cushions to prevent scratches',
          icon: Shield,
          importance: 'medium'
        },
        {
          title: 'Avoid Magnetic Fields',
          description: 'Keep away from speakers, phones, and magnetic closures that can affect accuracy',
          icon: AlertTriangle,
          importance: 'high'
        },
        {
          title: 'Climate Control',
          description: 'Store in a cool, dry place away from direct sunlight and humidity',
          icon: Sun,
          importance: 'medium'
        },
        {
          title: 'Separate Storage',
          description: 'Store each watch separately to prevent them from scratching each other',
          icon: CheckCircle,
          importance: 'low'
        }
      ]
    },
    maintenance: {
      title: 'Maintenance Schedule',
      icon: Wrench,
      tips: [
        {
          title: 'Annual Service Check',
          description: 'Have your watch inspected annually by certified technicians',
          icon: Wrench,
          importance: 'high'
        },
        {
          title: 'Water Resistance Testing',
          description: 'Test water resistance annually, especially for diving watches',
          icon: Droplets,
          importance: 'high'
        },
        {
          title: 'Movement Service',
          description: 'Service mechanical movements every 3-5 years to maintain accuracy',
          icon: Wrench,
          importance: 'medium'
        },
        {
          title: 'Battery Replacement',
          description: 'Replace quartz watch batteries every 2-3 years or when needed',
          icon: CheckCircle,
          importance: 'medium'
        }
      ]
    }
  };

  const watchTypes = [
    {
      type: 'Mechanical Watches',
      care: [
        'Wind regularly if not worn daily',
        'Avoid setting date between 9 PM - 3 AM',
        'Service every 3-5 years',
        'Keep away from magnetic fields'
      ],
      color: 'blue'
    },
    {
      type: 'Quartz Watches',
      care: [
        'Replace battery every 2-3 years',
        'Remove battery if storing long-term',
        'Clean contacts during battery change',
        'Check water resistance annually'
      ],
      color: 'green'
    },
    {
      type: 'Smart Watches',
      care: [
        'Charge regularly to maintain battery health',
        'Update software regularly',
        'Clean sensors and charging contacts',
        'Protect from extreme temperatures'
      ],
      color: 'purple'
    },
    {
      type: 'Diving Watches',
      care: [
        'Rinse with fresh water after saltwater use',
        'Test water resistance annually',
        'Check gaskets and seals regularly',
        'Avoid hot showers or saunas'
      ],
      color: 'orange'
    }
  ];

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const currentCategory = careCategories[selectedCategory];
  const CategoryIcon = currentCategory.icon;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <Shield className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Watch Care Instructions</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Proper care ensures your timepiece lasts for generations
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Category Selector */}
        <div className="mb-12">
          <div className="flex flex-wrap justify-center gap-4">
            {Object.entries(careCategories).map(([key, category]) => {
              const Icon = category.icon;
              return (
                <button
                  key={key}
                  onClick={() => setSelectedCategory(key as any)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-colors ${
                    selectedCategory === key
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {category.title}
                </button>
              );
            })}
          </div>
        </div>

        {/* Care Tips */}
        <div className="mb-16">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex items-center gap-3 mb-8">
              <CategoryIcon className="w-8 h-8 text-blue-600" />
              <h2 className="text-3xl font-bold text-gray-800">{currentCategory.title}</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {currentCategory.tips.map((tip, index) => {
                const TipIcon = tip.icon;
                return (
                  <div key={index} className="border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <TipIcon className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-gray-800">{tip.title}</h3>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getImportanceColor(tip.importance)}`}>
                            {tip.importance}
                          </span>
                        </div>
                        <p className="text-gray-600 text-sm">{tip.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Watch Type Specific Care */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Care by Watch Type</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {watchTypes.map((watch, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${
                  watch.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                  watch.color === 'green' ? 'bg-green-100 text-green-600' :
                  watch.color === 'purple' ? 'bg-purple-100 text-purple-600' :
                  'bg-orange-100 text-orange-600'
                }`}>
                  <Wrench className="w-6 h-6" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-800 mb-4">{watch.type}</h3>
                
                <ul className="space-y-2">
                  {watch.care.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Emergency Care */}
        <div className="bg-red-50 border border-red-200 rounded-2xl p-8 mb-16">
          <div className="flex items-center gap-3 mb-6">
            <AlertTriangle className="w-8 h-8 text-red-600" />
            <h2 className="text-2xl font-bold text-red-800">Emergency Care</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-red-800 mb-4">If Your Watch Gets Wet (Non-Water Resistant)</h3>
              <ul className="space-y-2 text-red-700">
                <li>• Remove immediately and dry thoroughly</li>
                <li>• Do not press any buttons or pull the crown</li>
                <li>• Place in rice or silica gel packets</li>
                <li>• Contact our service center immediately</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold text-red-800 mb-4">If Your Watch Stops Working</h3>
              <ul className="space-y-2 text-red-700">
                <li>• Check if it needs winding (mechanical)</li>
                <li>• Verify battery status (quartz)</li>
                <li>• Avoid shaking or tapping</li>
                <li>• Bring to authorized service center</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Professional Services */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <h2 className="text-3xl font-bold text-center mb-8">Professional Care Services</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Wrench className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Complete Service</h4>
              <p className="text-sm text-blue-100">Full movement service, cleaning, and calibration</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Droplets className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Water Resistance Test</h4>
              <p className="text-sm text-blue-100">Annual testing to ensure proper sealing</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Restoration</h4>
              <p className="text-sm text-blue-100">Professional restoration for vintage timepieces</p>
            </div>
          </div>
          
          <div className="text-center mt-8">
            <button 
              onClick={() => onNavigate('services')}
              className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors"
            >
              Book Service Appointment
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CareInstructions;