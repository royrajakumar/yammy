import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Smartphone, Building, Shield, CheckCircle, AlertCircle, Gift, Percent } from 'lucide-react';
import { PageProps } from '../types/watch';

const PaymentOptions: React.FC<PageProps> = ({ onNavigate }) => {
  const [selectedPayment, setSelectedPayment] = useState('card');

  const paymentMethods = [
    {
      id: 'card',
      name: 'Credit/Debit Cards',
      icon: CreditCard,
      description: 'Visa, MasterCard, American Express, RuPay',
      features: ['Instant payment', '3D Secure', 'International cards accepted', 'Save for future use'],
      processingTime: 'Instant',
      fees: 'No additional fees',
      color: 'blue'
    },
    {
      id: 'upi',
      name: 'UPI Payments',
      icon: Smartphone,
      description: 'Google Pay, PhonePe, Paytm, BHIM',
      features: ['Quick payments', 'No wallet top-up needed', 'Bank-grade security', 'QR code support'],
      processingTime: 'Instant',
      fees: 'No additional fees',
      color: 'green'
    },
    {
      id: 'netbanking',
      name: 'Net Banking',
      icon: Building,
      description: 'All major banks supported',
      features: ['Direct bank transfer', 'Secure banking portal', '50+ banks supported', 'Real-time confirmation'],
      processingTime: 'Instant',
      fees: 'No additional fees',
      color: 'purple'
    },
    {
      id: 'wallet',
      name: 'Digital Wallets',
      icon: Smartphone,
      description: 'Paytm, Amazon Pay, MobiKwik',
      features: ['Quick checkout', 'Cashback offers', 'Loyalty points', 'Instant refunds'],
      processingTime: 'Instant',
      fees: 'No additional fees',
      color: 'orange'
    },
    {
      id: 'emi',
      name: 'EMI Options',
      icon: CreditCard,
      description: 'Convert to easy installments',
      features: ['0% interest available', '3-24 months tenure', 'Pre-approved limits', 'Flexible payments'],
      processingTime: 'Instant approval',
      fees: 'Interest as per bank',
      color: 'indigo'
    },
    {
      id: 'cod',
      name: 'Cash on Delivery',
      icon: Gift,
      description: 'Pay when you receive',
      features: ['No advance payment', 'Cash or card at delivery', 'Available in select cities', 'Verification required'],
      processingTime: 'Order confirmation',
      fees: '₹100 handling fee',
      color: 'red'
    }
  ];

  const emiOptions = [
    { bank: 'HDFC Bank', tenure: '3-24 months', interest: '0% - 15%', minAmount: '₹10,000' },
    { bank: 'ICICI Bank', tenure: '3-18 months', interest: '0% - 13%', minAmount: '₹10,000' },
    { bank: 'SBI Cards', tenure: '6-24 months', interest: '0% - 16%', minAmount: '₹15,000' },
    { bank: 'Axis Bank', tenure: '3-12 months', interest: '0% - 14%', minAmount: '₹10,000' },
    { bank: 'Kotak Bank', tenure: '3-18 months', interest: '0% - 15%', minAmount: '₹12,000' },
    { bank: 'American Express', tenure: '3-12 months', interest: '0% - 12%', minAmount: '₹20,000' }
  ];

  const securityFeatures = [
    {
      icon: Shield,
      title: 'SSL Encryption',
      description: '256-bit SSL encryption for all transactions'
    },
    {
      icon: CheckCircle,
      title: 'PCI DSS Compliant',
      description: 'Highest level of payment security standards'
    },
    {
      icon: AlertCircle,
      title: 'Fraud Protection',
      description: 'Advanced fraud detection and prevention'
    },
    {
      icon: CreditCard,
      title: '3D Secure',
      description: 'Additional authentication for card payments'
    }
  ];

  const offers = [
    {
      type: 'Bank Offers',
      description: '10% instant discount on HDFC Bank cards',
      validity: 'Valid till 31st March',
      terms: 'Minimum purchase ₹50,000',
      color: 'blue'
    },
    {
      type: 'UPI Cashback',
      description: '₹500 cashback on UPI payments above ₹25,000',
      validity: 'Valid for first-time users',
      terms: 'Maximum cashback ₹500',
      color: 'green'
    },
    {
      type: 'EMI Offer',
      description: '0% interest on 6-month EMI',
      validity: 'Available on select cards',
      terms: 'Minimum purchase ₹30,000',
      color: 'purple'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-100 text-blue-600',
      green: 'bg-green-100 text-green-600',
      purple: 'bg-purple-100 text-purple-600',
      orange: 'bg-orange-100 text-orange-600',
      indigo: 'bg-indigo-100 text-indigo-600',
      red: 'bg-red-100 text-red-600'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <CreditCard className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-5xl font-bold mb-4">Payment Options</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Secure, convenient, and flexible payment methods for your luxury timepieces
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Payment Methods */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Choose Your Payment Method</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {paymentMethods.map((method) => {
              const IconComponent = method.icon;
              return (
                <div
                  key={method.id}
                  onClick={() => setSelectedPayment(method.id)}
                  className={`bg-white rounded-2xl shadow-lg p-6 cursor-pointer transition-all duration-200 hover:shadow-xl ${
                    selectedPayment === method.id ? 'ring-2 ring-blue-500 bg-blue-50' : ''
                  }`}
                >
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${getColorClasses(method.color)}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{method.name}</h3>
                  <p className="text-gray-600 mb-4">{method.description}</p>
                  
                  <div className="space-y-2 mb-4">
                    {method.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="border-t pt-4 space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Processing:</span>
                      <span className="font-medium text-gray-800">{method.processingTime}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Fees:</span>
                      <span className="font-medium text-gray-800">{method.fees}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* EMI Details */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">EMI Options</h2>
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
              <h3 className="text-xl font-bold">Convert your purchase into easy EMIs</h3>
              <p className="text-blue-100">Choose from multiple banks and tenure options</p>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Bank</th>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Tenure</th>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Interest Rate</th>
                    <th className="px-6 py-4 text-left font-semibold text-gray-800">Min Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {emiOptions.map((emi, index) => (
                    <tr key={index} className="border-t hover:bg-gray-50">
                      <td className="px-6 py-4 font-semibold text-blue-600">{emi.bank}</td>
                      <td className="px-6 py-4 text-gray-600">{emi.tenure}</td>
                      <td className="px-6 py-4 text-gray-600">{emi.interest}</td>
                      <td className="px-6 py-4 text-gray-600">{emi.minAmount}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="p-6 bg-blue-50">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> EMI options are subject to bank approval. Interest rates may vary based on your credit profile. 
                0% interest offers are available on select products and banks.
              </p>
            </div>
          </div>
        </div>

        {/* Current Offers */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Current Offers</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {offers.map((offer, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${
                  offer.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                  offer.color === 'green' ? 'bg-green-100 text-green-600' :
                  'bg-purple-100 text-purple-600'
                }`}>
                  <Percent className="w-6 h-6" />
                </div>
                
                <h3 className="text-lg font-bold text-gray-800 mb-2">{offer.type}</h3>
                <p className="text-gray-600 mb-3">{offer.description}</p>
                
                <div className="space-y-1 text-sm">
                  <p className="text-green-600 font-medium">{offer.validity}</p>
                  <p className="text-gray-500">{offer.terms}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Security Features */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Payment Security</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {securityFeatures.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div key={index} className="bg-white rounded-2xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="font-bold text-gray-800 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Payment Process */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white p-8">
          <h2 className="text-3xl font-bold text-center mb-8">How Payment Works</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">1</span>
              </div>
              <h4 className="font-semibold mb-2">Select Items</h4>
              <p className="text-sm text-blue-100">Add watches to cart and proceed to checkout</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">2</span>
              </div>
              <h4 className="font-semibold mb-2">Choose Payment</h4>
              <p className="text-sm text-blue-100">Select your preferred payment method</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">3</span>
              </div>
              <h4 className="font-semibold mb-2">Secure Payment</h4>
              <p className="text-sm text-blue-100">Complete payment through secure gateway</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold">4</span>
              </div>
              <h4 className="font-semibold mb-2">Order Confirmation</h4>
              <p className="text-sm text-blue-100">Receive instant confirmation and tracking</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentOptions;