import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Heart, 
  ShoppingCart, 
  User, 
  Clock,
  Menu,
  X,
  Minus,
  Plus,
  Trash2,
  Tag
} from 'lucide-react';
import { Watch } from '../types/watch';
import { formatPrice } from '../utils/currency';

interface CartItem extends Watch {
  quantity: number;
}

interface HeaderProps {
  onNavigate: (page: string) => void;
  cartItems: CartItem[];
  wishlistItems: Watch[];
  onAddToCart: (watch: Watch) => void;
  onRemoveFromCart: (watchId: string) => void;
  onUpdateQuantity: (watchId: string, quantity: number) => void;
  onToggleWishlist: (watch: Watch) => void;
  onClearCart: () => void;
  isTransparent?: boolean;
}

const Header: React.FC<HeaderProps> = ({
  onNavigate,
  cartItems,
  wishlistItems,
  onAddToCart,
  onRemoveFromCart,
  onUpdateQuantity,
  onToggleWishlist,
  onClearCart,
  isTransparent = false
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{code: string, discount: number} | null>(null);

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Format time to Indian timezone (IST)
  const formatIndianTime = (date: Date) => {
    return date.toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const cartTotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  const discountAmount = appliedCoupon ? (cartTotal * appliedCoupon.discount) / 100 : 0;
  const finalTotal = cartTotal - discountAmount;

  const handleApplyCoupon = () => {
    const coupons = {
      'WELCOME10': { discount: 10, description: '10% off on first purchase' },
      'LUXURY20': { discount: 20, description: '20% off on luxury watches' },
      'SAVE15': { discount: 15, description: '15% off on orders above ₹50,000' }
    };

    const coupon = coupons[couponCode.toUpperCase() as keyof typeof coupons];
    if (coupon) {
      setAppliedCoupon({ code: couponCode.toUpperCase(), discount: coupon.discount });
    } else {
      alert('Invalid coupon code');
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
  };

  const headerClasses = isTransparent 
    ? "absolute top-0 left-0 right-0 z-50 bg-transparent"
    : "bg-white/95 backdrop-blur-sm shadow-lg sticky top-0 z-50 border-b border-gray-200";

  const textClasses = isTransparent ? "text-white" : "text-gray-800";
  const logoClasses = isTransparent ? "text-white hover:text-yellow-400" : "text-gray-800 hover:text-blue-600";

  return (
    <>
      <header className={headerClasses}>
        <div className="container mx-auto px-6">
          {/* Top Bar */}
          <div className={`flex items-center justify-between py-2 text-sm border-b ${isTransparent ? 'border-white/20' : 'border-gray-100'}`}>
            <div className="flex items-center gap-4">
              <div className={`flex items-center gap-2 ${isTransparent ? 'text-yellow-400' : 'text-blue-600'}`}>
                <Clock className="w-4 h-4" />
                <span className="font-medium">IST: {formatIndianTime(currentTime)}</span>
              </div>
              <span className={isTransparent ? 'text-white/80' : 'text-gray-600'}>Free shipping on orders above ₹25,000</span>
            </div>
            <div className={`hidden md:flex items-center gap-4 ${isTransparent ? 'text-white/80' : 'text-gray-600'}`}>
              <span>📞 +91 11 2345 6789</span>
              <span>✉️ hello@timenest.com</span>
            </div>
          </div>

          {/* Main Header */}
          <div className="flex items-center justify-between py-4">
            {/* Logo */}
            <button 
              onClick={() => onNavigate('home')}
              className={`text-3xl font-bold transition-colors ${logoClasses}`}
            >
              Time<span className="text-yellow-400">Nest</span>
            </button>

            {/* Search Bar */}
            <div className="hidden lg:flex flex-1 max-w-2xl mx-8">
              <div className="relative w-full">
                <Search className={`absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 ${isTransparent ? 'text-white/60' : 'text-gray-400'}`} />
                <input
                  type="text"
                  placeholder="Search for watches, brands, or collections..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`w-full pl-12 pr-4 py-3 rounded-full focus:outline-none transition-colors ${
                    isTransparent 
                      ? 'bg-white/10 border-2 border-white/20 text-white placeholder-white/60 focus:bg-white/20 focus:border-white/40' 
                      : 'border-2 border-gray-200 focus:border-blue-500'
                  }`}
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-4">
              {/* Wishlist */}
              <button
                onClick={() => setIsWishlistOpen(true)}
                className={`relative p-2 transition-colors ${isTransparent ? 'text-white hover:text-red-400' : 'text-gray-600 hover:text-red-500'}`}
              >
                <Heart className="w-6 h-6" />
                {wishlistItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {wishlistItems.length}
                  </span>
                )}
              </button>

              {/* Cart */}
              <button
                onClick={() => setIsCartOpen(true)}
                className={`relative p-2 transition-colors ${isTransparent ? 'text-white hover:text-blue-400' : 'text-gray-600 hover:text-blue-500'}`}
              >
                <ShoppingCart className="w-6 h-6" />
                {cartItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cartItems.reduce((total, item) => total + item.quantity, 0)}
                  </span>
                )}
              </button>

              {/* Profile */}
              <button
                onClick={() => setIsProfileOpen(true)}
                className={`p-2 transition-colors ${isTransparent ? 'text-white hover:text-green-400' : 'text-gray-600 hover:text-green-500'}`}
              >
                <User className="w-6 h-6" />
              </button>

              {/* Mobile Menu */}
              <button
                onClick={() => setIsMenuOpen(true)}
                className={`lg:hidden p-2 ${isTransparent ? 'text-white hover:text-blue-400' : 'text-gray-600 hover:text-blue-500'}`}
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Cart Sidebar */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsCartOpen(false)}></div>
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
            <div className="flex flex-col h-full">
              {/* Cart Header */}
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-xl font-bold">Shopping Cart ({cartItems.reduce((total, item) => total + item.quantity, 0)})</h2>
                <button onClick={() => setIsCartOpen(false)}>
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Cart Items */}
              <div className="flex-1 overflow-y-auto p-6">
                {cartItems.length === 0 ? (
                  <div className="text-center py-12">
                    <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Your cart is empty</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex gap-4 p-4 border rounded-lg">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-sm">{item.name}</h3>
                          <p className="text-gray-600 text-sm">{item.brand}</p>
                          <p className="font-bold text-blue-600">{formatPrice(item.price)}</p>
                          
                          <div className="flex items-center gap-2 mt-2">
                            <button
                              onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                              className="p-1 hover:bg-gray-100 rounded"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="px-2 py-1 bg-gray-100 rounded text-sm">{item.quantity}</span>
                            <button
                              onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                              className="p-1 hover:bg-gray-100 rounded"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => onRemoveFromCart(item.id)}
                              className="p-1 hover:bg-red-100 text-red-500 rounded ml-2"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Cart Footer */}
              {cartItems.length > 0 && (
                <div className="border-t p-6 space-y-4">
                  {/* Coupon Section */}
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Enter coupon code"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        className="flex-1 px-3 py-2 border rounded-lg text-sm"
                      />
                      <button
                        onClick={handleApplyCoupon}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg text-sm hover:bg-green-700"
                      >
                        Apply
                      </button>
                    </div>
                    {appliedCoupon && (
                      <div className="flex items-center justify-between bg-green-50 p-2 rounded">
                        <div className="flex items-center gap-2 text-green-700 text-sm">
                          <Tag className="w-4 h-4" />
                          <span>{appliedCoupon.code} ({appliedCoupon.discount}% off)</span>
                        </div>
                        <button onClick={removeCoupon} className="text-red-500 hover:text-red-700">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Total */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal:</span>
                      <span>{formatPrice(cartTotal)}</span>
                    </div>
                    {appliedCoupon && (
                      <div className="flex justify-between text-sm text-green-600">
                        <span>Discount:</span>
                        <span>-{formatPrice(discountAmount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold text-lg border-t pt-2">
                      <span>Total:</span>
                      <span>{formatPrice(finalTotal)}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">
                      Proceed to Checkout
                    </button>
                    <button
                      onClick={onClearCart}
                      className="w-full border border-red-500 text-red-500 py-2 rounded-lg hover:bg-red-50"
                    >
                      Clear Cart
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Wishlist Sidebar */}
      {isWishlistOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsWishlistOpen(false)}></div>
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-xl font-bold">Wishlist ({wishlistItems.length})</h2>
                <button onClick={() => setIsWishlistOpen(false)}>
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6">
                {wishlistItems.length === 0 ? (
                  <div className="text-center py-12">
                    <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Your wishlist is empty</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {wishlistItems.map((item) => (
                      <div key={item.id} className="flex gap-4 p-4 border rounded-lg">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-sm">{item.name}</h3>
                          <p className="text-gray-600 text-sm">{item.brand}</p>
                          <p className="font-bold text-blue-600">{formatPrice(item.price)}</p>
                          <div className="flex gap-2 mt-2">
                            <button
                              onClick={() => onAddToCart(item)}
                              className="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700"
                            >
                              Add to Cart
                            </button>
                            <button
                              onClick={() => onToggleWishlist(item)}
                              className="px-3 py-1 border text-red-500 text-xs rounded hover:bg-red-50"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Profile Sidebar */}
      {isProfileOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsProfileOpen(false)}></div>
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-xl font-bold">My Account</h2>
                <button onClick={() => setIsProfileOpen(false)}>
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="flex-1 p-6">
                <div className="text-center mb-6">
                  <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="w-10 h-10 text-blue-600" />
                  </div>
                  <h3 className="font-semibold">Welcome to TimeNest</h3>
                  <p className="text-gray-600 text-sm">Sign in to access your account</p>
                </div>

                <div className="space-y-3">
                  <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">
                    Sign In
                  </button>
                  <button className="w-full border border-blue-600 text-blue-600 py-3 rounded-lg font-semibold hover:bg-blue-50">
                    Create Account
                  </button>
                </div>

                <div className="mt-8 space-y-4">
                  <button 
                    onClick={() => { onNavigate('orders'); setIsProfileOpen(false); }}
                    className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                  >
                    My Orders
                  </button>
                  <button 
                    onClick={() => { onNavigate('profile'); setIsProfileOpen(false); }}
                    className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                  >
                    Profile Settings
                  </button>
                  <button 
                    onClick={() => { onNavigate('addresses'); setIsProfileOpen(false); }}
                    className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                  >
                    Saved Addresses
                  </button>
                  <button 
                    onClick={() => { onNavigate('support'); setIsProfileOpen(false); }}
                    className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                  >
                    Customer Support
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsMenuOpen(false)}></div>
          <div className="absolute left-0 top-0 h-full w-80 bg-white shadow-xl">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">Menu</h2>
                <button onClick={() => setIsMenuOpen(false)}>
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              {/* Mobile Search */}
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search watches..."
                  className="w-full pl-10 pr-4 py-3 border rounded-lg"
                />
              </div>

              {/* Navigation Links */}
              <div className="space-y-4">
                <button 
                  onClick={() => { onNavigate('home'); setIsMenuOpen(false); }}
                  className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                >
                  Home
                </button>
                <button 
                  onClick={() => { onNavigate('collection'); setIsMenuOpen(false); }}
                  className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                >
                  Our Collection
                </button>
                <button 
                  onClick={() => { onNavigate('brands'); setIsMenuOpen(false); }}
                  className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                >
                  Brand Partners
                </button>
                <button 
                  onClick={() => { onNavigate('stores'); setIsMenuOpen(false); }}
                  className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                >
                  Store Locator
                </button>
                <button 
                  onClick={() => { onNavigate('services'); setIsMenuOpen(false); }}
                  className="w-full text-left p-3 hover:bg-gray-50 rounded-lg"
                >
                  Watch Services
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;