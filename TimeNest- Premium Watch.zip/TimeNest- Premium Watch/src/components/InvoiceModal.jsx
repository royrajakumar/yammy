import React from 'react';
import { X, Download, Printer as Print, CheckCircle, Calendar, MapPin, CreditCard } from 'lucide-react';
import { formatPrice } from '../utils/currency';

const InvoiceModal = ({ isOpen, onClose, orderData }) => {
  if (!isOpen || !orderData) return null;

  const generateInvoiceNumber = () => {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `INV-${year}${month}${day}-${random}`;
  };

  const invoiceNumber = generateInvoiceNumber();
  const invoiceDate = new Date().toLocaleDateString('en-IN');
  const dueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN');

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // Create a new window with the invoice content
    const printWindow = window.open('', '_blank');
    const invoiceContent = document.getElementById('invoice-content').innerHTML;
    
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice ${invoiceNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .invoice-header { text-align: center; margin-bottom: 30px; }
            .invoice-details { margin-bottom: 20px; }
            .invoice-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .invoice-table th, .invoice-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            .invoice-table th { background-color: #f2f2f2; }
            .total-section { text-align: right; margin-top: 20px; }
            @media print { body { margin: 0; } }
          </style>
        </head>
        <body>
          ${invoiceContent}
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black/50 transition-opacity" onClick={onClose}></div>
        
        <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-800">Invoice</h2>
            <div className="flex items-center gap-3">
              <button
                onClick={handleDownload}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                Download
              </button>
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <Print className="w-4 h-4" />
                Print
              </button>
              <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Invoice Content */}
          <div id="invoice-content" className="p-8">
            {/* Invoice Header */}
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gray-800 mb-2">
                Time<span className="text-yellow-500">Nest</span>
              </h1>
              <p className="text-gray-600">Premium Watch Store</p>
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg inline-block">
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-semibold">Payment Successful</span>
                </div>
              </div>
            </div>

            {/* Invoice Details */}
            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Invoice Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Invoice Number:</span>
                    <span className="font-semibold">{invoiceNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Order ID:</span>
                    <span className="font-semibold">{orderData.orderId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Invoice Date:</span>
                    <span>{invoiceDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Due Date:</span>
                    <span>{dueDate}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Company Details</h3>
                <div className="text-sm text-gray-600">
                  <p className="font-semibold text-gray-800">TimeNest Private Limited</p>
                  <p>123 Luxury Plaza, Connaught Place</p>
                  <p>New Delhi 110001, India</p>
                  <p>GST: 07AABCT1234M1Z5</p>
                  <p>Phone: +91 11 2345 6789</p>
                  <p>Email: hello@timenest.com</p>
                </div>
              </div>
            </div>

            {/* Billing Information */}
            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Bill To</h3>
                <div className="text-sm text-gray-600">
                  <p className="font-semibold text-gray-800">{orderData.shipping.fullName}</p>
                  <p>{orderData.shipping.address}</p>
                  <p>{orderData.shipping.city}, {orderData.shipping.state} - {orderData.shipping.pincode}</p>
                  <p>Phone: {orderData.shipping.phone}</p>
                  <p>Email: {orderData.shipping.email}</p>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Payment Information</h3>
                <div className="text-sm text-gray-600">
                  <div className="flex items-center gap-2 mb-2">
                    <CreditCard className="w-4 h-4" />
                    <span className="capitalize">{orderData.payment.method}</span>
                  </div>
                  {orderData.payment.method === 'card' && (
                    <p>Card ending in {orderData.payment.cardNumber.slice(-4)}</p>
                  )}
                  {orderData.payment.method === 'upi' && (
                    <p>UPI ID: {orderData.payment.upiId}</p>
                  )}
                  <div className="flex items-center gap-2 mt-2 text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span>Payment Confirmed</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Items Table */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Items Purchased</h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="border border-gray-300 px-4 py-3 text-left">Item</th>
                      <th className="border border-gray-300 px-4 py-3 text-left">Brand</th>
                      <th className="border border-gray-300 px-4 py-3 text-center">Qty</th>
                      <th className="border border-gray-300 px-4 py-3 text-right">Unit Price</th>
                      <th className="border border-gray-300 px-4 py-3 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orderData.items.map((item, index) => (
                      <tr key={index}>
                        <td className="border border-gray-300 px-4 py-3">
                          <div className="flex items-center gap-3">
                            <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded" />
                            <div>
                              <p className="font-medium">{item.name}</p>
                              <p className="text-xs text-gray-600">{item.description}</p>
                            </div>
                          </div>
                        </td>
                        <td className="border border-gray-300 px-4 py-3">{item.brand}</td>
                        <td className="border border-gray-300 px-4 py-3 text-center">{item.quantity}</td>
                        <td className="border border-gray-300 px-4 py-3 text-right">{formatPrice(item.price)}</td>
                        <td className="border border-gray-300 px-4 py-3 text-right font-semibold">
                          {formatPrice(item.price * item.quantity)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Totals */}
            <div className="flex justify-end">
              <div className="w-full max-w-sm">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>{formatPrice(orderData.totals.subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping:</span>
                    <span>{orderData.totals.shipping === 0 ? 'Free' : formatPrice(orderData.totals.shipping)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST (18%):</span>
                    <span>{formatPrice(orderData.totals.tax)}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between font-bold text-lg">
                    <span>Total Amount:</span>
                    <span>{formatPrice(orderData.totals.total)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-12 pt-8 border-t text-center text-sm text-gray-600">
              <p className="mb-2">Thank you for shopping with TimeNest!</p>
              <p>For any queries, contact us at hello@timenest.com or +91 11 2345 6789</p>
              <p className="mt-4 text-xs">This is a computer-generated invoice and does not require a signature.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceModal;