import React from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock,
  Facebook,
  Twitter,
  Instagram,
  Youtube,
  Shield,
  Truck,
  CreditCard,
  RotateCcw
} from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const quickLinks = [
    { name: 'About Us', page: 'about' },
    { name: 'Our Collection', page: 'collection' },
    { name: 'Brand Partners', page: 'brands' },
    { name: 'Store Locator', page: 'stores' },
    { name: 'Watch Services', page: 'services' },
    { name: 'Warranty Info', page: 'warranty' },
    { name: 'Size Guide', page: 'size-guide' },
    { name: 'Care Instructions', page: 'care' }
  ];

  const customerService = [
    { name: 'Contact Support', page: 'contact-support' },
    { name: 'Track Your Order', page: 'track-order' },
    { name: 'Returns & Exchanges', page: 'returns' },
    { name: 'Shipping Info', page: 'shipping' },
    { name: 'Payment Options', page: 'payment' },
    { name: 'FAQ', page: 'faq' },
    { name: 'Live Chat', page: 'chat' },
    { name: 'Book Appointment', page: 'appointment' }
  ];

  return (
    <footer className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Company Info */}
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-bold mb-2">
                Time<span className="text-yellow-400">Nest</span>
              </h3>
              <p className="text-gray-300 leading-relaxed">
                Your premier destination for luxury timepieces. We curate the finest watches from renowned brands worldwide.
              </p>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-300">
                <MapPin className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <span>123 Luxury Plaza, Connaught Place, New Delhi 110001</span>
              </div>
              <div className="flex items-center gap-3 text-gray-300">
                <Phone className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <span>+91 11 2345 6789</span>
              </div>
              <div className="flex items-center gap-3 text-gray-300">
                <Mail className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <span>hello@timenest.com</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-yellow-400">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <button 
                    onClick={() => onNavigate(link.page)}
                    className="text-gray-300 hover:text-yellow-400 transition-colors duration-200 hover:underline text-left"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-yellow-400">Customer Service</h4>
            <ul className="space-y-3">
              {customerService.map((link) => (
                <li key={link.name}>
                  <button 
                    onClick={() => onNavigate(link.page)}
                    className="text-gray-300 hover:text-yellow-400 transition-colors duration-200 hover:underline text-left"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Store Hours & Features */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-yellow-400">Store Hours</h4>
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3 text-gray-300">
                <Clock className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <div>
                  <div>Mon - Sat: 10:00 AM - 9:00 PM</div>
                  <div>Sunday: 11:00 AM - 8:00 PM</div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h5 className="font-semibold text-white">Why Choose TimeNest?</h5>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm text-gray-300">
                  <Shield className="w-4 h-4 text-green-400" />
                  <span>Authentic Guarantee</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-300">
                  <Truck className="w-4 h-4 text-blue-400" />
                  <span>Free Shipping</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-300">
                  <CreditCard className="w-4 h-4 text-purple-400" />
                  <span>Secure Payment</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-300">
                  <RotateCcw className="w-4 h-4 text-orange-400" />
                  <span>30-Day Returns</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Newsletter Section */}
        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="text-center max-w-2xl mx-auto">
            <h4 className="text-xl font-semibold mb-3 text-yellow-400">Stay Connected</h4>
            <p className="text-gray-300 mb-6">
              Subscribe to our newsletter for exclusive offers and the latest watch collections.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto mb-6">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-full bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
              />
              <button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white px-6 py-3 rounded-full font-semibold transition-all duration-200 transform hover:scale-105">
                Subscribe
              </button>
            </div>

            {/* Social Media Links */}
            <div className="flex justify-center gap-4">
              {[
                { icon: Facebook, href: '#', label: 'Facebook' },
                { icon: Twitter, href: '#', label: 'Twitter' },
                { icon: Instagram, href: '#', label: 'Instagram' },
                { icon: Youtube, href: '#', label: 'YouTube' }
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-10 h-10 bg-white/10 hover:bg-yellow-400 text-white hover:text-gray-900 rounded-full flex items-center justify-center transition-all duration-200 transform hover:scale-110"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-700 bg-slate-900/50">
        <div className="container mx-auto px-6 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-gray-400">
              © 2024 TimeNest. All rights reserved. | Privacy Policy | Terms of Service
            </div>
            
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span>Powered by luxury and precision</span>
              <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;