import React from 'react';
import { Heart, ShoppingCart, Eye } from 'lucide-react';
import { Watch } from '../types/watch';
import { formatPrice } from '../utils/currency';

interface WatchCardProps {
  watch: Watch;
  onQuickView?: (watch: Watch) => void;
  onAddToCart: (watch: Watch) => void;
  onToggleWishlist: (watch: Watch) => void;
  isInWishlist: boolean;
  isInCart: boolean;
}

const WatchCard: React.FC<WatchCardProps> = ({ 
  watch, 
  onQuickView, 
  onAddToCart, 
  onToggleWishlist, 
  isInWishlist,
  isInCart 
}) => {
  const handleWishlistClick = () => {
    if (isInWishlist) {
      // If already in wishlist, add to cart instead
      onAddToCart(watch);
    } else {
      // If not in wishlist, add to wishlist
      onToggleWishlist(watch);
    }
  };

  return (
    <div className="group relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 overflow-hidden">
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200">
        <img
          src={watch.image}
          alt={watch.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = `https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop&crop=center`;
          }}
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
            <button
              onClick={() => onQuickView?.(watch)}
              className="bg-white/90 hover:bg-white text-gray-800 p-2 rounded-full transition-all duration-200 transform hover:scale-110"
            >
              <Eye className="w-4 h-4" />
            </button>
            <button 
              onClick={handleWishlistClick}
              className={`p-2 rounded-full transition-all duration-200 transform hover:scale-110 ${
                isInWishlist 
                  ? 'bg-blue-500 text-white hover:bg-blue-600' 
                  : 'bg-white/90 hover:bg-white text-gray-800'
              }`}
              title={isInWishlist ? 'Add to Cart' : 'Add to Wishlist'}
            >
              {isInWishlist ? (
                <ShoppingCart className="w-4 h-4" />
              ) : (
                <Heart className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>

        {/* Category Badge */}
        <div className="absolute top-3 left-3">
          <span className={`px-2 py-1 text-xs font-semibold rounded-full text-white ${
            watch.category === 'luxury' ? 'bg-yellow-500' :
            watch.category === 'sport' ? 'bg-blue-500' :
            watch.category === 'classic' ? 'bg-gray-600' :
            'bg-green-500'
          }`}>
            {watch.category.toUpperCase()}
          </span>
        </div>

        {/* Wishlist Badge */}
        {isInWishlist && (
          <div className="absolute top-3 right-3">
            <span className="bg-red-500 text-white px-2 py-1 text-xs font-semibold rounded-full">
              ♥ Wishlist
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-6 space-y-4">
        {/* Brand */}
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-gray-500 uppercase tracking-wide">
            {watch.brand}
          </span>
          <span className="text-xs text-gray-400">{watch.movement}</span>
        </div>

        {/* Name */}
        <h3 className="font-bold text-lg text-gray-800 line-clamp-2 group-hover:text-blue-600 transition-colors duration-200">
          {watch.name}
        </h3>

        {/* Description */}
        <p className="text-gray-600 text-sm line-clamp-2 leading-relaxed">
          {watch.description}
        </p>

        {/* Details */}
        <div className="flex items-center gap-4 text-xs text-gray-500">
          <span className="bg-gray-100 px-2 py-1 rounded">{watch.material}</span>
          <span className="bg-gray-100 px-2 py-1 rounded capitalize">{watch.gender}</span>
        </div>

        {/* Price and Action */}
        <div className="flex items-center justify-between pt-2 border-t border-gray-100">
          <div className="space-y-1">
            <div className="text-2xl font-bold text-gray-800">
              {formatPrice(watch.price)}
            </div>
          </div>
          
          <button 
            onClick={() => onAddToCart(watch)}
            disabled={isInCart}
            className={`px-3 py-2 rounded-full font-medium transition-all duration-200 transform hover:scale-105 flex items-center gap-2 shadow-lg text-sm ${
              isInCart 
                ? 'bg-green-600 text-white cursor-not-allowed' 
                : 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white'
            }`}
          >
            <ShoppingCart className="w-3 h-3" />
            {isInCart ? 'In Cart' : 'Add to Cart'}
          </button>
        </div>
      </div>

      {/* 3D Effect Border */}
      <div className="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-blue-200 transition-colors duration-300 pointer-events-none"></div>
    </div>
  );
};

export default WatchCard;