import React, { useState, useMemo } from 'react';
import { Watch } from '../types/watch';
import { watches } from '../data/watches';
import WatchCard from './WatchCard';
import FilterBar from './FilterBar';
import { Loader2 } from 'lucide-react';

interface WatchGridProps {
  onAddToCart: (watch: Watch) => void;
  onToggleWishlist: (watch: Watch) => void;
  cartItems: Watch[];
  wishlistItems: Watch[];
}

const WatchGrid: React.FC<WatchGridProps> = ({ 
  onAddToCart, 
  onToggleWishlist, 
  cartItems, 
  wishlistItems 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange, setPriceRange] = useState<[number, number]>([15000, 515000]);
  const [displayCount, setDisplayCount] = useState(12);
  const [isLoading, setIsLoading] = useState(false);

  // Filter watches
  const filteredWatches = useMemo(() => {
    return watches.filter((watch) => {
      const matchesSearch = watch.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           watch.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           watch.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesBrand = selectedBrand === 'all' || watch.brand === selectedBrand;
      const matchesCategory = selectedCategory === 'all' || watch.category === selectedCategory;
      const matchesPrice = watch.price >= priceRange[0] && watch.price <= priceRange[1];

      return matchesSearch && matchesBrand && matchesCategory && matchesPrice;
    });
  }, [searchTerm, selectedBrand, selectedCategory, priceRange]);

  const displayedWatches = filteredWatches.slice(0, displayCount);

  const handleLoadMore = () => {
    setIsLoading(true);
    setTimeout(() => {
      setDisplayCount(prev => Math.min(prev + 12, filteredWatches.length));
      setIsLoading(false);
    }, 500);
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setSelectedBrand('all');
    setSelectedCategory('all');
    setPriceRange([15000, 515000]);
  };

  const handleQuickView = (watch: Watch) => {
    // Handle quick view modal
    console.log('Quick view:', watch);
  };

  const isInCart = (watchId: string) => cartItems.some(item => item.id === watchId);
  const isInWishlist = (watchId: string) => wishlistItems.some(item => item.id === watchId);

  return (
    <section className="min-h-screen bg-gray-50">
      <FilterBar
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        selectedBrand={selectedBrand}
        onBrandChange={setSelectedBrand}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        priceRange={priceRange}
        onPriceRangeChange={setPriceRange}
        onClearFilters={handleClearFilters}
      />

      <div className="container mx-auto px-6 py-8">
        {/* Results Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-800">Our Collection</h2>
            <p className="text-gray-600 mt-2">
              Showing {displayedWatches.length} of {filteredWatches.length} watches
            </p>
          </div>
          
          {/* Sort Options */}
          <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white">
            <option>Sort by: Featured</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Newest First</option>
            <option>Brand A-Z</option>
          </select>
        </div>

        {/* Watch Grid */}
        {displayedWatches.length > 0 ? (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 lg:gap-8">
              {displayedWatches.map((watch) => (
                <WatchCard 
                  key={watch.id} 
                  watch={watch} 
                  onQuickView={handleQuickView}
                  onAddToCart={onAddToCart}
                  onToggleWishlist={onToggleWishlist}
                  isInCart={isInCart(watch.id)}
                  isInWishlist={isInWishlist(watch.id)}
                />
              ))}
            </div>

            {/* Load More Button */}
            {displayCount < filteredWatches.length && (
              <div className="text-center mt-12">
                <button
                  onClick={handleLoadMore}
                  disabled={isLoading}
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-8 py-3 rounded-full font-semibold transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 mx-auto"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    `Load More (${filteredWatches.length - displayCount} remaining)`
                  )}
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">⌚</div>
            <h3 className="text-2xl font-semibold text-gray-800 mb-2">No watches found</h3>
            <p className="text-gray-600 mb-6">Try adjusting your filters or search terms</p>
            <button
              onClick={handleClearFilters}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full transition-colors duration-200"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default WatchGrid;