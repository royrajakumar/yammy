import React from 'react';
import { Clock, Star, Shield, Zap } from 'lucide-react';

interface HeroProps {
  onExploreCollection?: () => void;
  onWatchCatalog?: () => void;
}

const Hero: React.FC<HeroProps> = ({ onExploreCollection, onWatchCatalog }) => {
  return (
    <section className="relative min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-20 w-1 h-1 bg-blue-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-40 left-20 w-1.5 h-1.5 bg-yellow-300 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 right-10 w-2 h-2 bg-blue-300 rounded-full animate-ping delay-500"></div>
      </div>

      <div className="relative container mx-auto px-6 pt-32 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          {/* Left Content */}
          <div className="text-center lg:text-left space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight">
                Time
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
                  Nest
                </span>
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 font-light">
                Where Luxury Meets Precision
              </p>
            </div>

            <p className="text-lg text-gray-300 max-w-xl leading-relaxed">
              Discover our curated collection of 400+ premium timepieces from 20 world-renowned brands. 
              Each watch tells a story of craftsmanship, innovation, and timeless elegance.
            </p>

            <div className="flex flex-wrap gap-6 justify-center lg:justify-start">
              <div className="flex items-center gap-2 text-yellow-400">
                <Star className="w-5 h-5 fill-current" />
                <span className="text-white">Premium Quality</span>
              </div>
              <div className="flex items-center gap-2 text-blue-400">
                <Shield className="w-5 h-5" />
                <span className="text-white">Authentic Guarantee</span>
              </div>
              <div className="flex items-center gap-2 text-green-400">
                <Zap className="w-5 h-5" />
                <span className="text-white">Fast Delivery</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button 
                onClick={onExploreCollection}
                className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-xl"
              >
                Explore Collection
              </button>
              <button 
                onClick={onWatchCatalog}
                className="border-2 border-white/30 hover:border-white/50 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 backdrop-blur-sm hover:bg-white/10"
              >
                Watch Catalog
              </button>
            </div>
          </div>

          {/* Right 3D Watch Animation */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              {/* Main watch container with 3D effect */}
              <div className="relative w-80 h-80 md:w-96 md:h-96">
                {/* Outer rotating ring */}
                <div className="absolute inset-0 border-4 border-yellow-400/30 rounded-full animate-spin-slow"></div>
                <div className="absolute inset-4 border-2 border-blue-400/40 rounded-full animate-reverse-spin"></div>
                
                {/* Watch face */}
                <div className="absolute inset-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-full shadow-2xl transform hover:scale-105 transition-transform duration-500">
                  {/* Watch markers */}
                  <div className="absolute inset-4 rounded-full border border-yellow-400/20">
                    {[...Array(12)].map((_, i) => (
                      <div
                        key={i}
                        className="absolute w-1 h-6 bg-yellow-400 rounded-full"
                        style={{
                          top: '8px',
                          left: '50%',
                          transformOrigin: '50% 140px',
                          transform: `translateX(-50%) rotate(${i * 30}deg)`,
                        }}
                      />
                    ))}
                  </div>
                  
                  {/* Clock hands */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Clock className="w-32 h-32 text-yellow-400 animate-pulse" />
                  </div>
                  
                  {/* Center dot */}
                  <div className="absolute top-1/2 left-1/2 w-4 h-4 bg-yellow-400 rounded-full transform -translate-x-1/2 -translate-y-1/2 shadow-lg"></div>
                </div>

                {/* Floating elements */}
                <div className="absolute -top-8 -right-8 w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full opacity-20 animate-float"></div>
                <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full opacity-30 animate-float-delayed"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 pt-16 border-t border-white/10">
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-yellow-400">400+</div>
            <div className="text-gray-300 mt-2">Premium Watches</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-blue-400">20</div>
            <div className="text-gray-300 mt-2">Luxury Brands</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-green-400">10K+</div>
            <div className="text-gray-300 mt-2">Happy Customers</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-purple-400">5★</div>
            <div className="text-gray-300 mt-2">Average Rating</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;