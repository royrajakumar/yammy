import React, { useState, useEffect } from 'react';
import { User, LogOut, Settings, Package, Heart, MapPin, CreditCard } from 'lucide-react';
import { getCurrentUser, signOutUser, onAuthStateChange } from '../utils/auth';

const UserProfile = ({ onNavigate, onClose }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Listen for auth state changes
    const unsubscribe = onAuthStateChange((user) => {
      setUser(user);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleSignOut = async () => {
    const result = await signOutUser();
    if (result.success) {
      onClose();
    }
  };

  if (loading) {
    return (
      <div className="p-6 text-center">
        <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
        <p className="text-gray-600 mt-2">Loading...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="p-6 text-center">
        <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <User className="w-10 h-10 text-blue-600" />
        </div>
        <h3 className="font-semibold text-gray-800 mb-2">Welcome to TimeNest</h3>
        <p className="text-gray-600 text-sm mb-4">Sign in to access your account and enjoy personalized features</p>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* User Info */}
      <div className="text-center mb-6">
        <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          {user.photoURL ? (
            <img 
              src={user.photoURL} 
              alt={user.displayName || 'User'} 
              className="w-20 h-20 rounded-full object-cover"
            />
          ) : (
            <User className="w-10 h-10 text-blue-600" />
          )}
        </div>
        <h3 className="font-semibold text-gray-800">{user.displayName || 'TimeNest Customer'}</h3>
        <p className="text-gray-600 text-sm">{user.email}</p>
        <div className="mt-2">
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
            Verified Account
          </span>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <div className="text-lg font-bold text-gray-800">0</div>
          <div className="text-xs text-gray-600">Orders</div>
        </div>
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <div className="text-lg font-bold text-gray-800">0</div>
          <div className="text-xs text-gray-600">Wishlist</div>
        </div>
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <div className="text-lg font-bold text-gray-800">₹0</div>
          <div className="text-xs text-gray-600">Spent</div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="space-y-2">
        <button 
          onClick={() => { onNavigate('track-order'); onClose(); }}
          className="w-full text-left p-3 hover:bg-gray-50 rounded-lg flex items-center gap-3"
        >
          <Package className="w-5 h-5 text-gray-600" />
          <span>My Orders</span>
        </button>
        
        <button 
          onClick={() => { onNavigate('wishlist'); onClose(); }}
          className="w-full text-left p-3 hover:bg-gray-50 rounded-lg flex items-center gap-3"
        >
          <Heart className="w-5 h-5 text-gray-600" />
          <span>Wishlist</span>
        </button>
        
        <button 
          onClick={() => { onNavigate('addresses'); onClose(); }}
          className="w-full text-left p-3 hover:bg-gray-50 rounded-lg flex items-center gap-3"
        >
          <MapPin className="w-5 h-5 text-gray-600" />
          <span>Addresses</span>
        </button>
        
        <button 
          onClick={() => { onNavigate('payment-methods'); onClose(); }}
          className="w-full text-left p-3 hover:bg-gray-50 rounded-lg flex items-center gap-3"
        >
          <CreditCard className="w-5 h-5 text-gray-600" />
          <span>Payment Methods</span>
        </button>
        
        <button 
          onClick={() => { onNavigate('profile-settings'); onClose(); }}
          className="w-full text-left p-3 hover:bg-gray-50 rounded-lg flex items-center gap-3"
        >
          <Settings className="w-5 h-5 text-gray-600" />
          <span>Account Settings</span>
        </button>
        
        <button 
          onClick={() => { onNavigate('contact-support'); onClose(); }}
          className="w-full text-left p-3 hover:bg-gray-50 rounded-lg flex items-center gap-3"
        >
          <User className="w-5 h-5 text-gray-600" />
          <span>Customer Support</span>
        </button>
      </div>

      {/* Sign Out */}
      <div className="mt-6 pt-4 border-t">
        <button
          onClick={handleSignOut}
          className="w-full text-left p-3 hover:bg-red-50 rounded-lg flex items-center gap-3 text-red-600"
        >
          <LogOut className="w-5 h-5" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
};

export default UserProfile;