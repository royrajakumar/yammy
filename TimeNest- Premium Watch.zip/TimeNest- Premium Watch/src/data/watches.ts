import { Watch, Brand } from '../types/watch';

export const brands: Brand[] = [
  { name: 'Rolex', logo: '👑', description: 'Swiss luxury timepieces', founded: '1905', country: 'Switzerland' },
  { name: 'Omega', logo: 'Ω', description: 'Precision and elegance', founded: '1848', country: 'Switzerland' },
  { name: 'Seiko', logo: '⚡', description: 'Japanese innovation', founded: '1881', country: 'Japan' },
  { name: 'Casio', logo: '🔷', description: 'Digital technology leader', founded: '1946', country: 'Japan' },
  { name: 'Tissot', logo: '🇨🇭', description: 'Swiss tradition since 1853', founded: '1853', country: 'Switzerland' },
  { name: 'Fossil', logo: '🦕', description: 'American classic design', founded: '1984', country: 'USA' },
  { name: 'Citizen', logo: '🌟', description: 'Eco-drive technology', founded: '1918', country: 'Japan' },
  { name: 'TAG Heuer', logo: '🏎️', description: 'Swiss avant-garde', founded: '1860', country: 'Switzerland' },
  { name: 'Breitling', logo: '✈️', description: 'Aviation timepieces', founded: '1884', country: 'Switzerland' },
  { name: 'IWC', logo: '⚙️', description: 'International Watch Co.', founded: '1868', country: 'Switzerland' },
  { name: 'Patek Philippe', logo: '💎', description: 'Geneva\'s finest', founded: '1839', country: 'Switzerland' },
  { name: 'Audemars Piguet', logo: '🏔️', description: 'Royal Oak heritage', founded: '1875', country: 'Switzerland' },
  { name: 'Vacheron Constantin', logo: '⚜️', description: 'Oldest Swiss manufacturer', founded: '1755', country: 'Switzerland' },
  { name: 'Jaeger-LeCoultre', logo: '🎭', description: 'Grande Maison', founded: '1833', country: 'Switzerland' },
  { name: 'Cartier', logo: '💍', description: 'Jeweler of kings', founded: '1847', country: 'France' },
  { name: 'Panerai', logo: '⚓', description: 'Italian naval heritage', founded: '1860', country: 'Italy' },
  { name: 'Hublot', logo: '🔥', description: 'Art of fusion', founded: '1980', country: 'Switzerland' },
  { name: 'Zenith', logo: '⭐', description: 'Swiss precision', founded: '1865', country: 'Switzerland' },
  { name: 'Tudor', logo: '🛡️', description: 'Born to dare', founded: '1926', country: 'Switzerland' },
  { name: 'Longines', logo: '🏇', description: 'Elegance is an attitude', founded: '1832', country: 'Switzerland' }
];

const watchNames = [
  'Submariner', 'Speedmaster', 'Datejust', 'Seamaster', 'GMT-Master',
  'Daytona', 'Aquanaut', 'Nautilus', 'Royal Oak', 'Patrimony',
  'Master Control', 'Santos', 'Luminor', 'Big Bang', 'El Primero',
  'Heritage', 'Black Bay', 'Conquest', 'PilotWatch', 'Portugieser',
  'Chronomat', 'Navitimer', 'Monaco', 'Formula 1', 'Aquaracer',
  'Carrera', 'Link', 'Automatic', 'Quartz', 'Chronograph'
];

const materials = ['Stainless Steel', 'Gold', 'Platinum', 'Titanium', 'Ceramic', 'Carbon Fiber', 'Leather', 'Rubber'];
const movements = ['Automatic', 'Quartz', 'Manual', 'Solar', 'Kinetic'];
const categories: Watch['category'][] = ['luxury', 'sport', 'classic', 'smart'];
const genders: Watch['gender'][] = ['men', 'women', 'unisex'];
const features = ['Chronograph', 'GMT', 'Date Display', 'Moon Phase', 'Power Reserve', 'Diving Bezel', 'Tachymeter'];
const waterResistance = ['30m', '50m', '100m', '200m', '300m', '500m'];
const warranties = ['2 Years', '3 Years', '5 Years', 'Lifetime'];

// Better watch images from Pexels
const watchImages = [
  'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/277390/pexels-photo-277390.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697214/pexels-photo-1697214.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1034063/pexels-photo-1034063.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697215/pexels-photo-1697215.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697216/pexels-photo-1697216.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697217/pexels-photo-1697217.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697218/pexels-photo-1697218.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697219/pexels-photo-1697219.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697220/pexels-photo-1697220.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697221/pexels-photo-1697221.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697222/pexels-photo-1697222.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697223/pexels-photo-1697223.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697224/pexels-photo-1697224.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697225/pexels-photo-1697225.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697226/pexels-photo-1697226.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697227/pexels-photo-1697227.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697228/pexels-photo-1697228.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697229/pexels-photo-1697229.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
  'https://images.pexels.com/photos/1697230/pexels-photo-1697230.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop'
];

// Generate 400 watches (20 per brand)
export const watches: Watch[] = brands.flatMap((brand, brandIndex) => 
  Array.from({ length: 20 }, (_, i) => {
    const watchIndex = brandIndex * 20 + i;
    const basePrice = Math.floor(Math.random() * 500000) + 15000; // ₹15,000 to ₹515,000
    
    return {
      id: `watch-${watchIndex + 1}`,
      name: `${brand.name} ${watchNames[Math.floor(Math.random() * watchNames.length)]} ${i + 1}`,
      brand: brand.name,
      price: basePrice,
      image: watchImages[watchIndex % watchImages.length],
      description: `Premium ${categories[Math.floor(Math.random() * categories.length)]} watch with ${materials[Math.floor(Math.random() * materials.length)]} construction and ${movements[Math.floor(Math.random() * movements.length)]} movement.`,
      category: categories[Math.floor(Math.random() * categories.length)],
      gender: genders[Math.floor(Math.random() * genders.length)],
      material: materials[Math.floor(Math.random() * materials.length)],
      movement: movements[Math.floor(Math.random() * movements.length)],
      features: features.slice(0, Math.floor(Math.random() * 3) + 2),
      waterResistance: waterResistance[Math.floor(Math.random() * waterResistance.length)],
      warranty: warranties[Math.floor(Math.random() * warranties.length)]
    };
  })
);